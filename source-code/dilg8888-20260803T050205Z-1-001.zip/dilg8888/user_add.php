<?php
require 'auth.php';
require 'config.php';

$role = $_SESSION['role'] ?? 'viewer';
if ($role !== 'encoder') {
    http_response_code(403);
    die("Forbidden");
}

function h($s)
{
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

// fallback if missing
if (!function_exists('getDisplayRole')) {
    function getDisplayRole($r)
    {
        return htmlspecialchars((string)$r);
    }
}

// Load municipalities
$muniStmt = $pdo->query("SELECT id, name FROM municipalities ORDER BY name ASC");
$municipalities = $muniStmt->fetchAll(PDO::FETCH_ASSOC);

$error = "";

// Defaults for sticky form
$full_name = "";
$username = "";
$newRole = "";
$municipality_id = 0;
$is_active = 1;

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $full_name = trim($_POST["full_name"] ?? "");
    $username  = trim($_POST["username"] ?? "");
    $password  = $_POST["password"] ?? "";
    $newRole   = trim($_POST["role"] ?? "");
    $municipality_id = (int)($_POST["municipality_id"] ?? 0);
    $is_active = isset($_POST["is_active"]) ? 1 : 0;

    $needsFullName = ($newRole === "encoder");

    // ✅ validation (Full Name required only for encoder)
    if ($username === "" || $password === "" || $newRole === "") {
        $error = "Please fill in all required fields.";
    } elseif ($needsFullName && $full_name === "") {
        $error = "Full Name is required for encoder accounts.";
    } elseif (strlen($username) < 3) {
        $error = "Username must be at least 3 characters.";
    } elseif (strlen($password) < 6) {
        $error = "Password must be at least 6 characters.";
    } else {

        // ✅ If NOT encoder, force full_name blank (ignore whatever user typed)
        if (!$needsFullName) {
            $full_name = "";
        }

        // If not responder/mlgoo, force municipality null
        if ($newRole !== "responder" && $newRole !== "mlgoo") {
            $municipality_id = 0;
        }

        // Unique username check
        $chk = $pdo->prepare("SELECT id FROM users WHERE username = ? LIMIT 1");
        $chk->execute([$username]);
        if ($chk->fetchColumn()) {
            $error = "Username already exists.";
        } else {
            $hash = password_hash($password, PASSWORD_BCRYPT);

            $stmt = $pdo->prepare("
                INSERT INTO users (full_name, username, password_hash, role, municipality_id, is_active)
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $full_name,
                $username,
                $hash,
                $newRole,
                ($municipality_id > 0 ? $municipality_id : null),
                $is_active
            ]);

            header("Location: users_list.php");
            exit;
        }
    }
}

/* ✅ Page settings for global layout */
$pageTitle  = "Add User - EP 8888";
$activePage = "add_user";

/* ✅ Move page-specific CSS into extraHead */
$extraHead = <<<HTML
<style>
  /* IMPORTANT:
     The global layout already provides body/app/sidebar/topbar/content styles in assets/css/layout.css
     So we REMOVE those and only keep page-specific styles below.
  */

  .card {
    background: var(--card);
    border: 1px solid var(--line);
    border-radius: 10px;
    overflow: hidden;
    padding: 16px;
  }

  h2 {
    margin: 8px 0 12px 0;
    text-align: center;
    font-size: 28px;
  }

  .btn {
    display: inline-block;
    padding: 10px 14px;
    border-radius: 10px;
    background: #fff;
    border: 1px solid var(--line);
    text-decoration: none;
    color: #111;
    font-weight: 900;
    cursor: pointer;
  }

  .btn:hover {
    background: #f2f6ff;
  }

  .btn.primary {
    background: #0a4aa6;
    border-color: #0a4aa6;
    color: #fff;
  }

  .btn.gray {
    background: #334155;
    border-color: #334155;
    color: #fff;
  }

  .row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
  }

  @media (max-width: 900px) {
    .row {
      grid-template-columns: 1fr;
    }
  }

  label {
    display: block;
    font-size: 13px;
    color: #374151;
    font-weight: 800;
    margin-bottom: 6px;
  }

  input,
  select {
    width: 100%;
    padding: 12px 12px;
    border: 1px solid var(--line);
    border-radius: 10px;
    outline: none;
    background: #fff;
  }

  .muted-sm {
    color: #6b7280;
    font-size: 13px;
    font-weight: 700;
  }

  .err {
    background: #fee2e2;
    border: 1px solid #fecaca;
    color: #991b1b;
    padding: 10px 12px;
    border-radius: 10px;
    margin: 12px 0;
    font-weight: 800;
  }
</style>
HTML;

/* ✅ include global header/sidebar */
include __DIR__ . "/partials/layout_top.php";
?>

<div class="card">
    <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;">
        <h2 style="margin:0;text-align:left;">Create Account</h2>
        <a class="btn gray" href="users_list.php">← Back</a>
    </div>

    <?php if ($error): ?>
        <div class="err"><?php echo h($error); ?></div>
    <?php endif; ?>

    <form method="POST" style="margin-top:12px;">
        <div class="row">

            <!-- ✅ Full Name shows only if role = encoder -->
            <div id="fullNameWrap">
                <label>Full Name (encoder only) *</label>
                <input id="fullNameInput" name="full_name" value="<?php echo h($full_name); ?>">
            </div>

            <div>
                <label>Username *</label>
                <input name="username" value="<?php echo h($username); ?>" required>
            </div>

            <div>
                <label>Password *</label>
                <input type="password" name="password" required>
                <div class="muted-sm">Min 6 characters</div>
            </div>

            <div>
                <label>Role *</label>
                <select name="role" id="roleSel" required>
                    <option value="">-- Select Role --</option>
                    <option value="encoder"   <?php echo ($newRole === 'encoder') ? 'selected' : ''; ?>>encoder</option>
                    <option value="responder" <?php echo ($newRole === 'responder') ? 'selected' : ''; ?>>responder</option>
                    <option value="mlgoo"     <?php echo ($newRole === 'mlgoo') ? 'selected' : ''; ?>>mlgoo</option>
                  
                </select>
            </div>

            <div>
                <label>Municipality (for responder/mlgoo only)</label>
                <select name="municipality_id" id="muniSel">
                    <option value="0">-- None --</option>
                    <?php foreach ($municipalities as $m): ?>
                        <option value="<?php echo (int)$m['id']; ?>" <?php echo ((int)$municipality_id === (int)$m['id']) ? 'selected' : ''; ?>>
                            <?php echo h($m['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div style="display:flex;align-items:end;gap:10px;">
                <label style="display:flex;align-items:center;gap:8px;font-weight:800;margin:0;">
                    <input type="checkbox" name="is_active" <?php echo ($is_active === 1) ? 'checked' : ''; ?> style="width:auto;">
                    Active
                </label>
            </div>

        </div>

        <div style="margin-top:14px;display:flex;gap:10px;justify-content:center;flex-wrap:wrap;">
            <button class="btn primary" type="submit">✅ Create User</button>
        </div>
    </form>
</div>

<script>
    const roleSel = document.getElementById('roleSel');
    const muniSel = document.getElementById('muniSel');

    const fullNameWrap = document.getElementById('fullNameWrap');
    const fullNameInput = document.getElementById('fullNameInput');

    function syncMuni() {
        const r = roleSel.value;
        const needsMuni = (r === 'responder' || r === 'mlgoo');
        muniSel.disabled = !needsMuni;
        if (!needsMuni) muniSel.value = "0";
    }

    function syncFullName() {
        const needs = (roleSel.value === 'encoder');
        fullNameWrap.style.display = needs ? '' : 'none';
        fullNameInput.required = needs;
        if (!needs) fullNameInput.value = '';
    }

    roleSel.addEventListener('change', () => { syncMuni(); syncFullName(); });
    syncMuni();
    syncFullName();
</script>

<?php
/* ✅ include global footer/scripts */
include __DIR__ . "/partials/layout_bottom.php";
?>