<?php
require 'auth.php';
require 'config.php';

$role = $_SESSION['role'] ?? 'viewer';
if ($role !== 'encoder') {
    http_response_code(403);
    die("Forbidden");
}

// fallback if missing in other files
if (!function_exists('getDisplayRole')) {
    function getDisplayRole($r)
    {
        return htmlspecialchars((string)$r);
    }
}

// Load municipalities for display
$muniStmt = $pdo->query("SELECT id, name FROM municipalities ORDER BY name ASC");
$municipalities = $muniStmt->fetchAll(PDO::FETCH_ASSOC);
$muniMap = [];
foreach ($municipalities as $m) $muniMap[(int)$m['id']] = $m['name'];

// Fetch users
$stmt = $pdo->query("SELECT id, full_name, username, role, municipality_id, is_active, created_at
                     FROM users
                     ORDER BY id DESC");
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

function h($s)
{
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

/* ✅ Page settings for global layout */
$pageTitle  = "Users - EP 8888";
$activePage = "users";

/* ✅ Move page-specific CSS into extraHead */
$extraHead = <<<HTML
<style>
  /* IMPORTANT:
     The global layout already provides body/app/sidebar/topbar/content styles in assets/css/layout.css
     So we REMOVE those and only keep page-specific styles below.
  */

  h2 {
    margin: 8px 0 12px 0;
    text-align: center;
    font-size: 28px;
  }

  .card {
    background: var(--card);
    border: 1px solid var(--line);
    border-radius: 10px;
    overflow: hidden;
    padding: 16px;
  }

  .grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 10px;
  }

  .box {
    border: 1px solid var(--line);
    border-radius: 10px;
    padding: 10px;
    background: #fff;
    min-width: 0;
  }

  .muted {
    color: #6b7280;
    font-size: 12px;
    margin-bottom: 6px;
    font-weight: 700;
  }

  .value {
    font-weight: 900;
    color: #111;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .danger {
    color: var(--danger);
    font-weight: 900;
    margin: 0 0 12px;
    text-align: center;
  }

  .actions {
    display: flex;
    gap: 10px;
    margin-top: 14px;
    justify-content: center;
    flex-wrap: wrap;
  }

  .btn {
    display: inline-block;
    padding: 10px 14px;
    border-radius: 10px;
    background: #fff;
    border: 1px solid var(--line);
    text-decoration: none;
    color: #111;
    font-weight: 900;
    cursor: pointer;
  }

  .btn:hover {
    background: #f2f6ff;
  }

  .btn-danger {
    background: var(--danger);
    border: 1px solid var(--danger);
    color: #fff;
  }

  .btn-danger:hover {
    opacity: .92;
  }

  .row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
  }

  @media (max-width: 900px) {
    .row {
      grid-template-columns: 1fr;
    }
  }

  label {
    display: block;
    font-size: 13px;
    color: #374151;
    font-weight: 800;
    margin-bottom: 6px;
  }

  input,
  select {
    width: 100%;
    padding: 12px 12px;
    border: 1px solid var(--line);
    border-radius: 10px;
    outline: none;
    background: #fff;
  }

  .btn.primary {
    background: #0a4aa6;
    border-color: #0a4aa6;
    color: #fff;
  }

  .btn.gray {
    background: #334155;
    border-color: #334155;
    color: #fff;
  }

  .err {
    background: #fee2e2;
    border: 1px solid #fecaca;
    color: #991b1b;
    padding: 10px 12px;
    border-radius: 10px;
    margin: 12px 0;
    font-weight: 800;
  }

  .table-wrap {
    width: 100%;
    overflow: auto;
    border-radius: 10px;
  }

  table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 12px;
    min-width: 880px;
  }

  th,
  td {
    padding: 10px;
    border-bottom: 1px solid var(--line);
    text-align: left;
    font-size: 14px;
    vertical-align: top;
  }

  th {
    background: #f6f8fc;
    font-weight: 900;
  }

  .pill {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 999px;
    background: #eef3ff;
    color: #0a4aa6;
    font-weight: 900;
    font-size: 12px;
  }

  .muted-sm {
    color: #6b7280;
    font-size: 13px;
    font-weight: 700;
  }
</style>
HTML;

/* ✅ include global header/sidebar */
include __DIR__ . "/partials/layout_top.php";
?>

<div class="card">
    <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;">
        <h2 style="margin:0;text-align:left;">Users</h2>
        <a class="btn primary" href="user_add.php">➕ Add New User</a>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Username</th>
                    <th>Role</th>
                    <th>Municipality</th>
                    <th>Status</th>
                    <th>Created</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $u): ?>
                    <?php
                    $mid = (int)($u['municipality_id'] ?? 0);
                    $mname = $mid ? ($muniMap[$mid] ?? ('#' . $mid)) : '—';
                    $active = (int)$u['is_active'] === 1;
                    ?>
                    <tr>
                        <td><?php echo h($u['username']); ?></td>
                        <td><span class="pill"><?php echo h($u['role']); ?></span></td>
                        <td class="muted-sm"><?php echo h($mname); ?></td>
                        <td><?php echo $active ? 'Active' : '<span style="color:#b00020;font-weight:900;">Inactive</span>'; ?></td>
                        <td class="muted-sm"><?php echo h($u['created_at']); ?></td>
                        <td>
                            <a class="btn primary" style="padding:8px 10px;border-radius:10px" href="user_edit.php?id=<?php echo (int)$u['id']; ?>">✏️ Edit</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

</div>

<?php
/* ✅ include global footer/scripts */
include __DIR__ . "/partials/layout_bottom.php";
?>