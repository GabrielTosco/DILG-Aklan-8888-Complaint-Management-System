        </div> <!-- /content -->
    </main> <!-- /main -->

</div> <!-- /app -->

<script>
  // Sidebar collapse toggle
  (function () {
    const sidebar = document.getElementById('sidebar');
    const burger = document.getElementById('burger');
    if (!sidebar || !burger) return;

    burger.addEventListener('click', () => {
      sidebar.classList.toggle('collapsed');
    });
  })();
</script>

</body>
</html>
