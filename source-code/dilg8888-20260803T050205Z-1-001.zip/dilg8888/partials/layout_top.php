<?php
// expects: $pageTitle, $activePage
// uses: $_SESSION['role'], getDisplayRole()

$role = $_SESSION['role'] ?? 'viewer';

// Keep dashboard link behavior (preserve municipality_id if present)
$dashboardHref = 'dashboard_analytics.php';
if (isset($_GET['municipality_id'])) {
    $dashboardHref .= '?municipality_id=' . (int)$_GET['municipality_id'];
}

// ✅ Active helper (supports string or array)
function navActive($key, $activePage)
{
    if (is_array($key)) {
        return in_array($activePage, $key, true) ? 'active' : '';
    }
    return ($key === $activePage) ? 'active' : '';
}

// ✅ Normalize activePage for pages that reuse a shared key
// This fixes cases where Add Complaint / Add New User don't highlight correctly.
$activePage = $activePage ?? '';
$__page = basename($_SERVER['PHP_SELF'] ?? '');

// Force correct highlight by filename:
if ($__page === 'complaint_add.php') $activePage = 'add_complaint';
if ($__page === 'user_add.php')      $activePage = 'user_add';

// Sensible defaults if a page forgot to set $activePage:
if ($activePage === '') {
    if (in_array($__page, ['complaints_list.php', 'complaint_edit.php', 'complaint_view.php'], true)) $activePage = 'complaints';
    if (in_array($__page, ['users_list.php', 'user_edit.php'], true))                               $activePage = 'users';
    if (in_array($__page, ['dashboard_analytics.php', 'dashboard.php'], true))                      $activePage = 'dashboard';
}
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title><?php echo htmlspecialchars($pageTitle ?? 'Citizen Complaints Monitoring'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Global Layout CSS -->
    <link rel="stylesheet" href="assets/css/layout.css">

    <?php
    // Optional: if a page sets $extraHead (scripts/styles), print it here
    if (!empty($extraHead)) echo $extraHead;
    ?>
</head>

<body>
    <div class="app">

        <!-- SIDEBAR -->
        <aside class="sidebar" id="sidebar">
            <div class="brand">
                <img src="assets/img/logo_full.png" class="brand-logo-full" alt="EP 8888 Logo">
                <img src="assets/img/logo_icon.png" class="brand-logo-icon" alt="EP 8888 Icon">
            </div>

            <nav class="nav">
                <a class="<?php echo navActive('dashboard', $activePage); ?>" href="<?php echo $dashboardHref; ?>">
                    <div class="icon">🏠</div><span>Dashboard</span>
                </a>

                <a class="<?php echo navActive('complaints', $activePage); ?>" href="complaints_list.php">
                    <div class="icon">📄</div><span>Complaints List</span>
                </a>

                <?php if ($role === 'encoder'): ?>
                    <a class="<?php echo navActive('add_complaint', $activePage); ?>" href="complaint_add.php">
                        <div class="icon">➕</div><span>Add Complaint</span>
                    </a>


                <?php endif; ?>

                <a href="#" onclick="window.close(); return false;">
                    <div class="icon">❌</div><span>Close</span>
                </a>
                </a>
            </nav>
        </aside>

        <!-- MAIN -->
        <main class="main">
            <div class="topbar">
                <div class="topbar-left">
                    <button class="burger" id="burger" title="Toggle sidebar">☰</button>
                    <div class="top-title">Citizen's Complaints Monitoring</div>
                </div>

                <div class="topbar-right">
                    <?php echo getDisplayRole($_SESSION['role'] ?? ''); ?>

                    <div class="avatar">
                        <img
                            src="assets/icons/<?php echo (($_SESSION['role'] ?? '') === 'encoder') ? 'encoder.png' : 'responder.png'; ?>"
                            alt="User Avatar">
                    </div>
                </div>
            </div>

            <div class="content">