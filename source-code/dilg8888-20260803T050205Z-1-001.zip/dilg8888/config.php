<?php
// Database configuration
$host = "localhost";
$dbname = "dilg8888_db";
$username = "root";
$password = ""; // default for XAMPP

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8",
        $username,
        $password
    );
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
function getDisplayRole($role) {
    switch ($role) {
        case 'responder':
            return 'LGU';
        case 'mlgoo':
            return 'MLGOO';
        case 'encoder':
            return 'Admin';
        default:
            return ucfirst($role);
    }
}
