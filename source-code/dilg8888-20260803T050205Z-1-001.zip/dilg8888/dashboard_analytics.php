<?php

require 'auth.php';
require 'config.php';

// Role shortcuts
$role = $_SESSION['role'] ?? 'viewer';
$userMunicipalityId = $_SESSION['municipality_id'] ?? null;

// Load municipalities
$muniStmt = $pdo->query("SELECT id, name FROM municipalities ORDER BY name ASC");
$municipalities = $muniStmt->fetchAll(PDO::FETCH_ASSOC);

// Determine selected municipality
// 0 = ALL MUNICIPALITIES
$selectedMunicipalityId = isset($_GET['municipality_id']) ? (int)$_GET['municipality_id'] : 0;

// ✅ Responder + MLGOO are locked to their own municipality
if ($role === 'responder' || $role === 'mlgoo') {
    $selectedMunicipalityId = (int)$userMunicipalityId;
}

// Selected municipality name
if ($role === 'responder' || $role === 'mlgoo') {
    $selectedMunicipalityName = '';
    foreach ($municipalities as $m) {
        if ((int)$m['id'] === (int)$selectedMunicipalityId) {
            $selectedMunicipalityName = $m['name'];
            break;
        }
    }
    if ($selectedMunicipalityName === '') $selectedMunicipalityName = 'Your Municipality';
} else {
    $selectedMunicipalityName = ($selectedMunicipalityId === 0) ? 'All Municipalities' : '';
    if ($selectedMunicipalityId !== 0) {
        foreach ($municipalities as $m) {
            if ((int)$m['id'] === (int)$selectedMunicipalityId) {
                $selectedMunicipalityName = $m['name'];
                break;
            }
        }
        if ($selectedMunicipalityName === '') $selectedMunicipalityName = 'All Municipalities';
    }
}

// Helper for date format
function fmt_dt($val)
{
    if (empty($val)) return '—';
    return date('d M Y h:i A', strtotime($val));
}

// Helper for shorter text
function trunc_txt($str, $max = 80)
{
    $str = (string)$str;
    $str = trim($str);
    if ($str === '') return '';
    if (function_exists('mb_strlen')) {
        return (mb_strlen($str, 'UTF-8') > $max) ? (mb_substr($str, 0, $max, 'UTF-8') . '…') : $str;
    }
    return (strlen($str) > $max) ? (substr($str, 0, $max) . '…') : $str;
}

/* =========================
   TABLES
   ========================= */
$pdo->exec("
    CREATE TABLE IF NOT EXISTS comment_notifications (
      id INT AUTO_INCREMENT PRIMARY KEY,
      complaint_id INT NOT NULL,
      comment_id INT NOT NULL,
      from_user_id INT NOT NULL,
      to_user_id INT NOT NULL,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      seen_at DATETIME NULL,
      UNIQUE KEY uniq_comment_to (comment_id, to_user_id),
      INDEX idx_to_seen_time (to_user_id, seen_at, created_at),
      INDEX idx_complaint (complaint_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

$pdo->exec("
    CREATE TABLE IF NOT EXISTS completion_notifications (
      id INT AUTO_INCREMENT PRIMARY KEY,
      complaint_id INT NOT NULL,
      from_user_id INT NOT NULL,
      to_user_id INT NOT NULL,
      completed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      seen_at DATETIME NULL,
      UNIQUE KEY uniq_complete_event (complaint_id, to_user_id, completed_at),
      INDEX idx_to_seen_time (to_user_id, seen_at, completed_at),
      INDEX idx_complaint (complaint_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

$pdo->exec("
    CREATE TABLE IF NOT EXISTS revision_notif_seen (
        user_id INT NOT NULL,
        complaint_id INT NOT NULL,
        revision_requested_at DATETIME NOT NULL DEFAULT '1970-01-01 00:00:00',
        seen_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (user_id, complaint_id),
        INDEX idx_revision_requested_at (revision_requested_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

try {
    $pdo->exec("
        ALTER TABLE revision_notif_seen
        ADD COLUMN revision_requested_at DATETIME NOT NULL DEFAULT '1970-01-01 00:00:00'
        AFTER complaint_id
    ");
} catch (Throwable $e) {
    // column already exists
}

try {
    $pdo->exec("
        CREATE INDEX idx_revision_requested_at
        ON revision_notif_seen (revision_requested_at)
    ");
} catch (Throwable $e) {
    // index already exists
}

/* =========================
   LGU/MLGOO NOTIFICATION HANDLERS
   RULES:
   - LGU/responder controls clearing
   - MLGOO can only view, never clear
   - When LGU clears/views certain notif types, MLGOO copy syncs too
   ========================= */

// ✅ NEW complaint notif: only LGU marks complaint as received (shared for LGU + MLGOO)
if (
    isset($_GET['open_new_notif']) &&
    ($role === 'responder' || $role === 'mlgoo')
) {
    $cid = (int)$_GET['open_new_notif'];
    if ($cid > 0) {
        $q = $pdo->prepare("
            SELECT id
            FROM complaints
            WHERE id = ?
              AND municipality_id = ?
            LIMIT 1
        ");
        $q->execute([$cid, (int)$userMunicipalityId]);
        $validId = (int)($q->fetchColumn() ?? 0);

        if ($validId > 0) {
            if ($role === 'responder') {
                $upd = $pdo->prepare("
                    UPDATE complaints
                    SET received_at = NOW()
                    WHERE id = ?
                      AND municipality_id = ?
                      AND (received_at IS NULL OR received_at = '')
                ");
                $upd->execute([$validId, (int)$userMunicipalityId]);
            }

            header("Location: complaint_view.php?id=" . $validId);
            exit;
        }
    }
}

// ✅ COMMENT notif: LGU opens = clear both LGU + MLGOO copies
if (isset($_GET['open_comment_notif'])) {
    $nid = (int)$_GET['open_comment_notif'];
    if ($nid > 0) {

        $q = $pdo->prepare("
            SELECT cn.complaint_id, c.municipality_id
            FROM comment_notifications cn
            JOIN complaints c ON c.id = cn.complaint_id
            WHERE cn.id = ?
              AND cn.to_user_id = ?
            LIMIT 1
        ");
        $q->execute([$nid, $_SESSION['user_id']]);
        $row = $q->fetch(PDO::FETCH_ASSOC);

        $cid = (int)($row['complaint_id'] ?? 0);
        $notifMunicipalityId = (int)($row['municipality_id'] ?? 0);

        if ($cid > 0) {

            if ($role === 'responder') {
                // LGU opening comment notif clears both responder + mlgoo copies
                $m = $pdo->prepare("
                    UPDATE comment_notifications cn
                    JOIN users u ON u.id = cn.to_user_id
                    JOIN complaints c ON c.id = cn.complaint_id
                    SET cn.seen_at = NOW()
                    WHERE cn.complaint_id = ?
                      AND c.municipality_id = ?
                      AND u.role IN ('responder', 'mlgoo')
                      AND cn.seen_at IS NULL
                ");
                $m->execute([$cid, $notifMunicipalityId]);
            } else {
                // encoder / mlgoo / others: clear only their own clicked notification
                $m = $pdo->prepare("
                    UPDATE comment_notifications
                    SET seen_at = NOW()
                    WHERE id = ?
                      AND to_user_id = ?
                      AND seen_at IS NULL
                ");
                $m->execute([$nid, $_SESSION['user_id']]);
            }

            header("Location: complaint_view.php?id=" . $cid);
            exit;
        }
    }
}

// ✅ COMPLETION notif view: nobody auto-clears on view
if (isset($_GET['open_complete_notif'])) {
    $nid = (int)$_GET['open_complete_notif'];
    if ($nid > 0) {
        $q = $pdo->prepare("
            SELECT complaint_id
            FROM completion_notifications
            WHERE id = ?
              AND to_user_id = ?
            LIMIT 1
        ");
        $q->execute([$nid, $_SESSION['user_id']]);
        $cid = (int)($q->fetchColumn() ?? 0);

        if ($cid > 0) {
            header("Location: complaint_view.php?id=" . $cid);
            exit;
        }
    }
}

// ✅ COMPLETION notif clear: only LGU can clear, and clears both LGU + MLGOO copies
if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['clear_completion_notif']) &&
    $role === 'responder'
) {
    $notifId = (int)$_POST['notif_id'];

    $q = $pdo->prepare("
        SELECT cn.complaint_id, c.municipality_id
        FROM completion_notifications cn
        JOIN complaints c ON c.id = cn.complaint_id
        WHERE cn.id = ?
          AND cn.to_user_id = ?
        LIMIT 1
    ");
    $q->execute([$notifId, $_SESSION['user_id']]);
    $row = $q->fetch(PDO::FETCH_ASSOC);

    $cid = (int)($row['complaint_id'] ?? 0);
    $notifMunicipalityId = (int)($row['municipality_id'] ?? 0);

    if ($cid > 0) {
        $del = $pdo->prepare("
            DELETE cn
            FROM completion_notifications cn
            JOIN users u ON u.id = cn.to_user_id
            JOIN complaints c ON c.id = cn.complaint_id
            WHERE cn.complaint_id = ?
              AND c.municipality_id = ?
              AND u.role IN ('responder', 'mlgoo')
        ");
        $del->execute([$cid, $notifMunicipalityId]);
    }

    header("Location: dashboard_analytics.php");
    exit;
}

// ✅ REVISION notif: only LGU marks seen, and marks both LGU + MLGOO as seen
if (($role === 'responder' || $role === 'mlgoo') && isset($_GET['open_revision'])) {
    $cid = (int)$_GET['open_revision'];
    if ($cid > 0) {

        $q = $pdo->prepare("
    SELECT id, municipality_id, revision_requested_at
    FROM complaints
    WHERE id = ?
      AND municipality_id = ?
    LIMIT 1
");
        $q->execute([$cid, (int)$userMunicipalityId]);
        $row = $q->fetch(PDO::FETCH_ASSOC);

        $validId = (int)($row['id'] ?? 0);
        $muniId  = (int)($row['municipality_id'] ?? 0);
        $currentRevisionRequestedAt = $row['revision_requested_at'] ?? '1970-01-01 00:00:00';

        if ($validId > 0) {

            if ($role === 'responder') {
                $usersStmt = $pdo->prepare("
                    SELECT id
                    FROM users
                    WHERE municipality_id = ?
                      AND role IN ('responder', 'mlgoo')
                ");
                $usersStmt->execute([$muniId]);
                $userIds = $usersStmt->fetchAll(PDO::FETCH_COLUMN);

                if ($userIds) {
                    $mark = $pdo->prepare("
    INSERT INTO revision_notif_seen (user_id, complaint_id, revision_requested_at, seen_at)
    VALUES (?, ?, ?, NOW())
    ON DUPLICATE KEY UPDATE
        revision_requested_at = VALUES(revision_requested_at),
        seen_at = NOW()
");

                    foreach ($userIds as $uid) {
                        $mark->execute([(int)$uid, $validId, $currentRevisionRequestedAt]);
                    }
                }
            }

            header("Location: complaint_view.php?id=" . $validId);
            exit;
        }
    }
}

/* =========================
   LOAD UNSEEN COMMENT NOTIFS FOR CURRENT USER
   ========================= */
$commentNotifs = [];
$cmStmt = $pdo->prepare("
    SELECT
        n.id AS notif_id,
        n.complaint_id,
        n.created_at,
        c.subject,
        m.name AS municipality_name,
        u.username AS from_username,
        u.role AS from_role
    FROM comment_notifications n
    JOIN complaints c ON c.id = n.complaint_id
    JOIN municipalities m ON m.id = c.municipality_id
    JOIN users u ON u.id = n.from_user_id
    WHERE n.to_user_id = ?
      AND n.seen_at IS NULL
    ORDER BY n.created_at DESC
    LIMIT 8
");
$cmStmt->execute([$_SESSION['user_id']]);
$commentNotifs = $cmStmt->fetchAll(PDO::FETCH_ASSOC);

/* =========================
   LOAD UNSEEN COMPLETION NOTIFS FOR CURRENT USER
   ========================= */
$completionNotifs = [];
$cpStmt = $pdo->prepare("
    SELECT
        n.id AS notif_id,
        n.complaint_id,
        n.completed_at,
        m.name AS municipality_name,
        u.username AS from_username,
        u.role AS from_role
    FROM completion_notifications n
    JOIN complaints c ON c.id = n.complaint_id
    JOIN municipalities m ON m.id = c.municipality_id
    JOIN users u ON u.id = n.from_user_id
    WHERE n.to_user_id = ?
      AND n.seen_at IS NULL
    ORDER BY n.completed_at DESC
    LIMIT 8
");
$cpStmt->execute([$_SESSION['user_id']]);
$completionNotifs = $cpStmt->fetchAll(PDO::FETCH_ASSOC);

/* =========================
   RESPONDER / MLGOO NOTIFICATIONS
   ========================= */
$notifications = [];
if ($role === 'responder' || $role === 'mlgoo') {
    $notifStmt = $pdo->prepare("
        SELECT c.id, c.subject, c.date_sent,
               u.full_name, u.username
        FROM complaints c
        LEFT JOIN users u ON u.id = c.encoded_by_user_id
        WHERE c.municipality_id = ?
          AND (c.received_at IS NULL OR c.received_at = '')
        ORDER BY c.date_sent DESC
        LIMIT 8
    ");
    $notifStmt->execute([(int)$userMunicipalityId]);
    $notifications = $notifStmt->fetchAll(PDO::FETCH_ASSOC);
}

/* =========================
   REVISION NOTIFS FOR RESPONDER / MLGOO
   ========================= */
$revisionNotifs = [];
if ($role === 'responder' || $role === 'mlgoo') {
    $revStmt = $pdo->prepare("
    SELECT c.id, c.updated_at, c.date_sent, c.revision_requested_at
    FROM complaints c
    JOIN users u ON u.id = c.revision_requested_by
    LEFT JOIN revision_notif_seen s
        ON s.user_id = ?
       AND s.complaint_id = c.id
    WHERE c.municipality_id = ?
      AND c.status = 'REVISING'
      AND c.revision_requested_at IS NOT NULL
      AND u.role = 'encoder'
      AND (
            s.complaint_id IS NULL
            OR s.revision_requested_at <> c.revision_requested_at
          )
    ORDER BY COALESCE(c.revision_requested_at, c.updated_at, c.date_sent) DESC
    LIMIT 8
");
    $revStmt->execute([$_SESSION['user_id'], (int)$userMunicipalityId]);
    $revisionNotifs = $revStmt->fetchAll(PDO::FETCH_ASSOC);
}

/* =========================
   ENCODER NOTIFICATIONS
   ========================= */
$encoderNotifications = [];
$encoderRevisionNotifications = [];

if ($role === 'encoder') {

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS encoder_notif_seen (
            encoder_user_id INT NOT NULL,
            complaint_id INT NOT NULL,
            seen_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (encoder_user_id, complaint_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    $pdo->exec("
    CREATE TABLE IF NOT EXISTS encoder_revision_seen (
        encoder_user_id INT NOT NULL,
        complaint_id INT NOT NULL,
        seen_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        revision_requested_at DATETIME NOT NULL DEFAULT '1970-01-01 00:00:00',
        PRIMARY KEY (encoder_user_id, complaint_id),
        INDEX idx_encoder_revision_seen_lookup (encoder_user_id, complaint_id, revision_requested_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

    if (isset($_GET['open_rev_notif'])) {
        $cid = (int)$_GET['open_rev_notif'];
        if ($cid > 0) {
            $revMeta = $pdo->prepare("
                SELECT revision_requested_at
                FROM complaints
                WHERE id = ?
                LIMIT 1
            ");
            $revMeta->execute([$cid]);
            $revRow = $revMeta->fetch(PDO::FETCH_ASSOC);

            $currentRevisionRequestedAt = $revRow['revision_requested_at'] ?? '1970-01-01 00:00:00';

            $mark = $pdo->prepare("
                INSERT INTO encoder_revision_seen (
                    encoder_user_id, complaint_id, seen_at, revision_requested_at
                )
                VALUES (?, ?, NOW(), ?)
                ON DUPLICATE KEY UPDATE
                    seen_at = NOW(),
                    revision_requested_at = VALUES(revision_requested_at)
            ");
            $mark->execute([$_SESSION['user_id'], $cid, $currentRevisionRequestedAt]);

            header("Location: complaint_view.php?id=" . $cid);
            exit;
        }
    }

    if (isset($_GET['open_notif'])) {
        $cid = (int)$_GET['open_notif'];
        if ($cid > 0) {
            $mark = $pdo->prepare("
                INSERT INTO encoder_notif_seen (encoder_user_id, complaint_id, seen_at)
                VALUES (?, ?, NOW())
                ON DUPLICATE KEY UPDATE seen_at = NOW()
            ");
            $mark->execute([$_SESSION['user_id'], $cid]);

            header("Location: complaint_view.php?id=" . $cid);
            exit;
        }
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['clear_encoder_notifs'])) {
        $idsStmt = $pdo->query("
            SELECT id
            FROM complaints
            WHERE status = 'PENDING' AND resolution_pdf_path IS NOT NULL
            ORDER BY date_sent DESC
            LIMIT 100
        ");
        $ids = $idsStmt->fetchAll(PDO::FETCH_COLUMN);

        if ($ids) {
            $mark = $pdo->prepare("
                INSERT INTO encoder_notif_seen (encoder_user_id, complaint_id, seen_at)
                VALUES (?, ?, NOW())
                ON DUPLICATE KEY UPDATE seen_at = NOW()
            ");
            foreach ($ids as $cid) {
                $mark->execute([$_SESSION['user_id'], (int)$cid]);
            }
        }
        $revIdsStmt = $pdo->query("
    SELECT id, revision_requested_at
    FROM complaints
    WHERE revision_requested_at IS NOT NULL
      AND resolved_at IS NOT NULL
      AND resolved_at >= revision_requested_at
      AND status IN ('PENDING', 'REVISING')
    ORDER BY COALESCE(resolved_at, updated_at, date_sent) DESC
    LIMIT 100
");
        $revIds = $revIdsStmt->fetchAll(PDO::FETCH_ASSOC);

        if ($revIds) {
            $markRev = $pdo->prepare("
                INSERT INTO encoder_revision_seen (
                    encoder_user_id, complaint_id, seen_at, revision_requested_at
                )
                VALUES (?, ?, NOW(), ?)
                ON DUPLICATE KEY UPDATE
                    seen_at = NOW(),
                    revision_requested_at = VALUES(revision_requested_at)
            ");
            foreach ($revIds as $row) {
                $markRev->execute([
                    $_SESSION['user_id'],
                    (int)$row['id'],
                    $row['revision_requested_at'] ?? '1970-01-01 00:00:00'
                ]);
            }
        }

        $clearCm = $pdo->prepare("
            UPDATE comment_notifications
            SET seen_at = NOW()
            WHERE to_user_id = ?
              AND seen_at IS NULL
        ");
        $clearCm->execute([$_SESSION['user_id']]);

        $back = "dashboard_analytics.php";
        if (isset($_GET['municipality_id'])) {
            $back .= "?municipality_id=" . (int)$_GET['municipality_id'];
        }
        header("Location: " . $back);
        exit;
    }
    $notifStmt = $pdo->prepare("
    SELECT c.id, c.subject, c.status, c.date_sent, m.name AS municipality_name
    FROM complaints c
    JOIN municipalities m ON m.id = c.municipality_id
    WHERE c.status = 'PENDING'
      AND c.resolution_pdf_path IS NOT NULL
      AND c.revision_requested_at IS NULL
      AND NOT EXISTS (
          SELECT 1
          FROM encoder_notif_seen s
          WHERE s.encoder_user_id = ?
            AND s.complaint_id = c.id
      )
    ORDER BY c.date_sent DESC
    LIMIT 8
");
    $notifStmt->execute([$_SESSION['user_id']]);
    $encoderNotifications = $notifStmt->fetchAll(PDO::FETCH_ASSOC);

    $revNotifStmt = $pdo->prepare("
    SELECT
        c.id,
        c.subject,
        c.resolved_at AS notif_time,
        m.name AS municipality_name
    FROM complaints c
    JOIN municipalities m ON m.id = c.municipality_id
    LEFT JOIN encoder_revision_seen s
        ON s.encoder_user_id = ?
       AND s.complaint_id = c.id
    WHERE c.revision_requested_at IS NOT NULL
      AND c.resolution_pdf_path IS NOT NULL
      AND c.resolved_at IS NOT NULL
      AND c.resolved_at >= c.revision_requested_at
      AND c.status = 'PENDING'
      AND (
            s.complaint_id IS NULL
            OR s.revision_requested_at <> c.revision_requested_at
          )
    GROUP BY c.id, c.subject, c.resolved_at, m.name
    ORDER BY c.resolved_at DESC
    LIMIT 8
");
    $revNotifStmt->execute([$_SESSION['user_id']]);
    $encoderRevisionNotifications = $revNotifStmt->fetchAll(PDO::FETCH_ASSOC);
}

/* =========================
   COMPLAINTS TABLE
   ========================= */
$tableParams = [];
$tableWheres = ["c.status IN ('PENDING','REFERRED','REVISING')"];

if ($selectedMunicipalityId > 0) {
    $tableWheres[] = "c.municipality_id = ?";
    $tableParams[] = $selectedMunicipalityId;
}

$tableWhere = "WHERE " . implode(" AND ", $tableWheres);

$complaintsStmt = $pdo->prepare("
    SELECT c.id, c.nature_of_call, c.status, c.date_sent, m.name AS municipality_name
    FROM complaints c
    JOIN municipalities m ON m.id = c.municipality_id
    $tableWhere
    ORDER BY c.date_sent DESC
    LIMIT 12
");

$complaintsStmt->execute($tableParams);
$complaints = $complaintsStmt->fetchAll(PDO::FETCH_ASSOC);

/* =========================
   COUNTS FOR CHARTS
   ========================= */
$countSql = "
    SELECT status, COUNT(*) AS cnt
    FROM complaints
";
$countParams = [];
if ($selectedMunicipalityId > 0) {
    $countSql .= " WHERE municipality_id = ?";
    $countParams[] = $selectedMunicipalityId;
}
$countSql .= " GROUP BY status";

$countStmt = $pdo->prepare($countSql);
$countStmt->execute($countParams);
$rows = $countStmt->fetchAll(PDO::FETCH_ASSOC);

$receivedCount = 0;
$pendingCount = 0;
$completeCount = 0;

foreach ($rows as $r) {
    $st = strtoupper($r['status']);
    if ($st === 'REFERRED') $receivedCount = (int)$r['cnt'];
    if ($st === 'PENDING')  $pendingCount  = (int)$r['cnt'];
    if ($st === 'COMPLETE') $completeCount = (int)$r['cnt'];
}

$total = $receivedCount + $pendingCount + $completeCount;
$notComplete = $total - $completeCount;
$completePercent = $total > 0 ? round(($completeCount / $total) * 100, 1) : 0.0;

/* =========================
   LAYOUT HOOK
   ========================= */
$pageTitle  = "Citizen's Complaints Monitoring - Dashboard";
$activePage = "dashboard";

$extraHead = <<<HTML
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
:root {
    --blue: #0a4aa6;
    --blue2: #0b61d8;
    --bg: #f3f6fb;
    --card: #ffffff;
    --line: #e5e7eb;
}

* {
    box-sizing: border-box;
    font-family: Arial, Helvetica, sans-serif;
}

.clamp-2 {
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
    overflow: hidden;
    word-break: break-word;
}

.content {
    padding: 16px;
    max-width: 1200px;
    margin: 0 auto;
    width: 100%;
}

h2 {
    margin: 8px 0 12px 0;
    text-align: center;
    font-size: 28px;
}

.quick-links {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
    margin: 0 0 12px 0;
    justify-content: center;
}

.btn {
    display: inline-block;
    padding: 10px 14px;
    border-radius: 10px;
    background: #fff;
    border: 1px solid var(--line);
    text-decoration: none;
    color: #111;
    font-weight: 800;
}

.btn:hover {
    background: #f2f6ff;
}

.grid-top {
    display: grid;
    grid-template-columns: 360px 1fr;
    gap: 14px;
}

.card {
    background: var(--card);
    border: 1px solid var(--line);
    border-radius: 10px;
    overflow: hidden;
}

.card-header {
    background: #1b2fbf;
    color: #fff;
    padding: 10px 12px;
    font-weight: 800;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
}
.notif-header-red {
    background: #c41e3a;
}

.pad {
    padding: 12px;
}

.muni-search {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px;
    border-bottom: 1px solid var(--line);
    background: #fff;
}

.muni-search input {
    width: 100%;
    padding: 10px 10px;
    border: 1px solid var(--line);
    border-radius: 8px;
    font-size: 14px;
}

.muni-list {
    max-height: 240px;
    overflow: auto;
}

.muni-item {
    display: block;
    padding: 10px 12px;
    border-bottom: 1px solid #f1f1f1;
    text-decoration: none;
    color: #111;
    font-size: 18px;
    line-height: 1.3;
}

.muni-item:hover {
    background: #f2f6ff;
}

.muni-item.active {
    background: #111;
    color: #fff;
}

.hint {
    font-size: 16px;
    color: #555;
    margin-top: 8px;
}

table {
    width: 100%;
    border-collapse: collapse;
}

th,
td {
    border-bottom: 1px solid var(--line);
    padding: 10px;
    font-size: 14px;
    text-align: left;
}

th {
    background: #eaf2ff;
    font-weight: 800;
}

.status-pill {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 999px;
    font-size: 12px;
    font-weight: 800;
    border: 1px solid var(--line);
}

.st-received {
    background: #eef2ff;
}

.st-pending {
    background: #fff6e5;
}

.st-complete {
    background: #e8fff1;
}

.st-revising {
    background: #fa848b;
}

.grid-bottom {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 14px;
    margin-top: 14px;
}

.chart-title {
    text-align: center;
    font-size: 22px;
    font-weight: 900;
    margin: 10px 0 0;
}

.chart-wrap {
    padding: 12px;
}

.badge {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 999px;
    background: rgba(255, 255, 255, .2);
    border: 1px solid rgba(255, 255, 255, .35);
    font-weight: 900;
    font-size: 12px;
}

.notif-list {
    padding: 12px;
    max-height: 300px;
    overflow-y: auto;
}

.notif-item {
    border: 1px solid var(--line);
    border-radius: 12px;
    padding: 12px;
    background: #fff;
    margin-bottom: 10px;
}

.notif-item .title {
    font-weight: 900;
    margin-bottom: 6px;
}

.notif-item .meta {
    color: #555;
    font-size: 12px;
    margin-top: 6px;
}

.notif-item a {
    display: inline-block;
    margin-top: 8px;
    font-weight: 900;
    color: var(--blue2);
    text-decoration: none;
}

.notif-item a:hover {
    text-decoration: underline;
}

@media (max-width: 980px) {
    .grid-top {
        grid-template-columns: 1fr;
    }

    .grid-bottom {
        grid-template-columns: 1fr;
    }
}

.notif-wrap {
    margin-top: 12px;
    border-top: 1px solid var(--line);
    padding-top: 12px;
}

.notif-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    margin-bottom: 10px;
}

.notif-title {
    font-weight: 900;
    font-size: 16px;
}

.notif-clear {
    padding: 8px 10px;
    border-radius: 10px;
    border: 1px solid var(--line);
    background: #fff;
    color: #111;
    font-weight: 900;
    cursor: pointer;
}

.notif-clear:hover {
    background: #f2f6ff;
}

.notif-item {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 10px;
    padding: 10px;
    border: 1px solid var(--line);
    border-radius: 10px;
    background: #fff;
    margin-bottom: 10px;
}

.notif-item b {
    display: block;
    margin-bottom: 2px;
}

.notif-sub {
    color: #444;
    font-size: 13px;
    line-height: 1.3;
}

.notif-actions {
    flex: 0 0 auto;
}

.notif-btn {
    display: inline-block;
    padding: 8px 10px;
    border-radius: 10px;
    background: #111;
    color: #fff;
    text-decoration: none;
    font-weight: 900;
}

.notif-empty {
    color: #666;
    font-size: 13px;
}

.complaints-scroll {
    max-height: 350px;
    overflow-y: auto;
}

.muni-updates-scroll {
    max-height: 420px;
    overflow-y: auto;
}

.notif-two-line {
    display: flex;
    flex-direction: column;
    gap: 6px;
}

.notif-title-line {
    font-weight: 700;
}

.notif-bottom-line {
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 15px;
    font-weight: 600;
    color: #333;
    width: 100%;
}

.notif-bottom-line span {
    flex-grow: 1;
    padding-right: 20px;
}

.notif-link {
    flex-shrink: 0;
    margin-left: 20px;
    font-weight: 900;
    color: var(--blue2);
    text-decoration: none;
}

.notif-link:hover {
    text-decoration: underline;
}
</style>
HTML;

include __DIR__ . "/partials/layout_top.php";
?>

<h2>Complaints Summary</h2>

<div class="quick-links">
    <?php if ($role === 'encoder'): ?>
        <a class="btn" href="complaint_add.php">➕ Add Complaint</a>
        <a class="btn" href="complaints_list.php">📄 View All Complaints</a>
    <?php elseif ($role === 'responder' || $role === 'mlgoo'): ?>
        <a class="btn" href="complaints_list.php">📄 View Assigned Complaints</a>
    <?php else: ?>
        <a class="btn" href="complaints_list.php">📄 View Complaints</a>
    <?php endif; ?>
</div>

<div class="grid-top">
    <?php if ($role === 'responder' || $role === 'mlgoo'): ?>

        <div class="card">
            <div class="card-header notif-header-red">
                <span>Notifications</span>
                <span class="badge"><?php echo (int)(count($notifications) + count($revisionNotifs) + count($commentNotifs) + count($completionNotifs)); ?></span>
            </div>
            <div class="notif-list">

                <?php if (count($notifications) === 0 && count($revisionNotifs) === 0 && count($commentNotifs) === 0 && count($completionNotifs) === 0): ?>
                    <div class="notif-item">
                        <div class="title">No new notifications.</div>
                        <div class="meta">You’re all caught up.</div>
                    </div>
                <?php endif; ?>

                <!-- NEW complaints -->
                <?php foreach ($notifications as $n): ?>
                    <div class="notif-item notif-two-line">
                        <div class="notif-title-line">
                            DILG endorsed a new complaint
                        </div>

                        <div class="notif-bottom-line">
                            <?php
                            $d = $n['date_sent'] ?? null;
                            $shortDate = $d ? date('M d, Y - h:i A', strtotime($d)) : '—';
                            ?>
                            <span><?php echo htmlspecialchars($shortDate); ?></span>
                            <a href="dashboard_analytics.php?open_new_notif=<?php echo (int)$n['id']; ?>" class="notif-link">View</a>
                        </div>
                    </div>
                <?php endforeach; ?>

                <!-- REVISION complaints -->
                <?php foreach ($revisionNotifs as $r): ?>
                    <div class="notif-item notif-two-line">
                        <div class="notif-title-line">
                            DILG requested for correction
                        </div>

                        <div class="notif-bottom-line">
                            <?php
                            $d = $r['updated_at'] ?? ($r['date_sent'] ?? null);
                            $shortDate = $d ? date('M d, Y - h:i A', strtotime($d)) : '—';
                            ?>
                            <span><?php echo htmlspecialchars($shortDate); ?></span>
                            <a href="dashboard_analytics.php?open_revision=<?php echo (int)$r['id']; ?>" class="notif-link">View</a>
                        </div>
                    </div>
                <?php endforeach; ?>

                <!-- COMMENT notifications -->
                <?php foreach ($commentNotifs as $cn): ?>
                    <div class="notif-item notif-two-line">
                        <div class="notif-title-line">
                            New comment from <?php echo htmlspecialchars(strtoupper($cn['from_role'])); ?>
                        </div>

                        <div class="notif-bottom-line">
                            <?php
                            $d = $cn['created_at'] ?? null;
                            $shortDate = $d ? date('M d, Y - h:i A', strtotime($d)) : '—';
                            ?>
                            <span><?php echo htmlspecialchars($shortDate); ?></span>
                            <a href="dashboard_analytics.php?open_comment_notif=<?php echo (int)$cn['notif_id']; ?>" class="notif-link">View</a>
                        </div>
                    </div>
                <?php endforeach; ?>

                <!-- COMPLETION notifications -->
                <?php foreach ($completionNotifs as $cp): ?>
                    <div class="notif-item notif-two-line">
                        <div class="notif-title-line">
                            Encoder completed a complaint
                        </div>

                        <div class="notif-bottom-line">
                            <?php
                            $d = $cp['completed_at'] ?? null;
                            $shortDate = $d ? date('M d, Y - h:i A', strtotime($d)) : '—';
                            ?>
                            <span><?php echo htmlspecialchars($shortDate); ?></span>

                            <?php if ($role === 'responder'): ?>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="notif_id" value="<?php echo (int)$cp['notif_id']; ?>">
                                    <button
                                        type="submit"
                                        name="clear_completion_notif"
                                        class="notif-link"
                                        style="background:#dc2626;color:#fff;border:none;padding:6px 12px;border-radius:6px;cursor:pointer;">
                                        Clear
                                    </button>
                                </form>
                            <?php elseif ($role === 'mlgoo'): ?>
                                <a href="dashboard_analytics.php?open_complete_notif=<?php echo (int)$cp['notif_id']; ?>" class="notif-link">View</a>
                            <?php else: ?>
                                <span style="color:#999;font-size:13px;">Notification</span>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>

            </div>
            <div class="pad">
                <div class="hint">
                    Municipality: <b><?php echo htmlspecialchars($selectedMunicipalityName); ?></b><br>
                    New = not yet clicked
                </div>
            </div>
        </div>

    <?php else: ?>

        <div class="card">
            <div class="muni-search">
                <span>🔎</span>
                <input id="muniSearch" type="text" placeholder="Search municipality...">
            </div>

            <div class="muni-list" id="muniList">
                <a class="muni-item <?php echo ($selectedMunicipalityId === 0 ? 'active' : ''); ?>"
                    href="dashboard_analytics.php?municipality_id=0"
                    data-name="all municipalities">
                    All Municipalities
                </a>

                <?php foreach ($municipalities as $m): ?>
                    <?php
                    $isActive = ((int)$m['id'] === (int)$selectedMunicipalityId);
                    $href = "dashboard_analytics.php?municipality_id=" . (int)$m['id'];
                    ?>
                    <a class="muni-item <?php echo $isActive ? 'active' : ''; ?>"
                        href="<?php echo htmlspecialchars($href); ?>"
                        data-name="<?php echo htmlspecialchars(strtolower($m['name'])); ?>">
                        <?php echo htmlspecialchars($m['name']); ?> Aklan
                    </a>
                <?php endforeach; ?>
            </div>

            <div class="pad">
                <div class="hint">
                    Selected: <b><?php echo htmlspecialchars($selectedMunicipalityName); ?></b><br>
                    Role: <b><?php echo htmlspecialchars($role); ?></b>
                </div>
            </div>
        </div>

    <?php endif; ?>

    <div class="card">
        <div class="card-header">
            <?php echo htmlspecialchars($selectedMunicipalityName); ?> Complaints
        </div>
        <div class="pad complaints-scroll">
            <table>
                <thead>
                    <tr>
                        <th>Municipality</th>
                        <th>Nature Of Call</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>View</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($complaints) === 0): ?>
                        <tr>
                            <td colspan="5">No complaints found.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($complaints as $idx => $c): ?>
                            <?php
                            $st = strtoupper($c['status']);
                            $stDisplay = ($st === 'REVISING') ? 'FOR CORRECTION' : $st;
                            $stClass = $st === 'COMPLETE' ? 'st-complete'
                                : ($st === 'PENDING' ? 'st-pending'
                                    : ($st === 'REVISING' ? 'st-revising'
                                        : 'st-received'));
                            ?>
                            <tr>
                                <td><?php echo htmlspecialchars($c['municipality_name'] ?? '—'); ?></td>

                                <td>
                                    <span class="clamp-2" title="<?php echo htmlspecialchars($c['nature_of_call'] ?? ''); ?>">
                                        <?php echo htmlspecialchars(trunc_txt(($c['nature_of_call'] ?? ''), 90)); ?>
                                    </span>
                                </td>

                                <td><?php echo htmlspecialchars(fmt_dt($c['date_sent'] ?? null)); ?></td>
                                <td><span class="status-pill <?php echo $stClass; ?>"><?php echo htmlspecialchars($stDisplay); ?></span></td>
                                <td>
                                    <a href="complaint_view.php?id=<?php echo (int)$c['id']; ?>">Open →</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="grid-bottom">
    <div class="card">
        <div class="chart-title">Complaints Chart</div>
        <div class="chart-wrap">
            <canvas id="barChart" height="170"></canvas>

            <?php if ($role === 'encoder'): ?>
                <div class="notif-wrap muni-updates-scroll">
                    <div class="notif-header">
                        <div class="notif-title">Municipality Updates</div>

                        <form method="post" style="margin:0;">
                            <button type="submit" class="notif-clear" name="clear_encoder_notifs"
                                onclick="return confirm('Clear all notifications?');">
                                Clear all
                            </button>
                        </form>
                    </div>

                    <?php
                    $hasResp = count($encoderNotifications) > 0;
                    $hasRev  = isset($encoderRevisionNotifications) && count($encoderRevisionNotifications) > 0;
                    $hasCm   = count($commentNotifs) > 0;
                    ?>

                    <?php if (!$hasResp && !$hasRev && !$hasCm): ?>
                        <div class="notif-empty">No new updates.</div>
                    <?php else: ?>

                        <?php foreach ($encoderNotifications as $n): ?>
                            <div class="notif-item">
                                <div>
                                    <b><?php echo htmlspecialchars($n['municipality_name']); ?> submitted a response</b>
                                    <div class="notif-sub">
                                        Subject:
                                        <span class="clamp-2" title="<?php echo htmlspecialchars($n['subject']); ?>">
                                            <?php echo htmlspecialchars(trunc_txt($n['subject'], 90)); ?>
                                        </span><br>
                                        Date sent: <?php echo htmlspecialchars(fmt_dt($n['date_sent'] ?? null)); ?>
                                    </div>
                                </div>

                                <div class="notif-actions">
                                    <a class="notif-btn"
                                        href="dashboard_analytics.php?open_notif=<?php echo (int)$n['id']; ?><?php echo (isset($_GET['municipality_id']) ? '&municipality_id=' . (int)$_GET['municipality_id'] : ''); ?>">
                                        View →
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; ?>

                        <?php foreach ($encoderRevisionNotifications as $r): ?>
                            <div class="notif-item">
                                <div>
                                    <b><?php echo htmlspecialchars($r['municipality_name']); ?> submitted a revision</b>
                                    <div class="notif-sub">
                                        Subject:
                                        <span class="clamp-2" title="<?php echo htmlspecialchars($r['subject']); ?>">
                                            <?php echo htmlspecialchars(trunc_txt($r['subject'], 90)); ?>
                                        </span><br>
                                        Date sent: <?php echo htmlspecialchars(fmt_dt($r['notif_time'] ?? null)); ?>
                                    </div>
                                </div>

                                <div class="notif-actions">
                                    <a class="notif-btn"
                                        href="dashboard_analytics.php?open_rev_notif=<?php echo (int)$r['id']; ?><?php echo (isset($_GET['municipality_id']) ? '&municipality_id=' . (int)$_GET['municipality_id'] : ''); ?>">
                                        View →
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; ?>

                        <?php foreach ($commentNotifs as $cn): ?>
                            <div class="notif-item">
                                <div>
                                    <b><?php echo htmlspecialchars($cn['municipality_name']); ?> posted a comment</b>
                                    <div class="notif-sub">
                                        From: <?php echo htmlspecialchars($cn['from_username']); ?> (<?php echo htmlspecialchars($cn['from_role']); ?>)<br>
                                        Subject:
                                        <span class="clamp-2" title="<?php echo htmlspecialchars($cn['subject']); ?>">
                                            <?php echo htmlspecialchars(trunc_txt($cn['subject'], 90)); ?>
                                        </span><br>
                                        Comment date: <?php echo htmlspecialchars(fmt_dt($cn['created_at'] ?? null)); ?>
                                    </div>
                                </div>

                                <div class="notif-actions">
                                    <a class="notif-btn"
                                        href="dashboard_analytics.php?open_comment_notif=<?php echo (int)$cn['notif_id']; ?><?php echo (isset($_GET['municipality_id']) ? '&municipality_id=' . (int)$_GET['municipality_id'] : ''); ?>">
                                        View →
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; ?>

                    <?php endif; ?>
                </div>
            <?php endif; ?>

        </div>
    </div>

    <div class="card">
        <div class="chart-title">Percentage Of Completion</div>
        <div class="chart-wrap">
            <canvas id="pieChart" height="170"></canvas>
            <div style="text-align:center;margin-top:8px;font-weight:800;">
                Complete: <?php echo htmlspecialchars((string)$completePercent); ?>%
            </div>
        </div>
    </div>
</div>

<script>
    const searchInput = document.getElementById('muniSearch');
    const muniList = document.getElementById('muniList');

    if (searchInput && muniList) {
        searchInput.addEventListener('input', () => {
            const q = searchInput.value.toLowerCase().trim();
            const items = muniList.querySelectorAll('.muni-item');
            items.forEach(a => {
                const name = (a.getAttribute('data-name') || '').toLowerCase();
                a.style.display = name.includes(q) ? 'block' : 'none';
            });
        });
    }

    const received = <?php echo (int)$receivedCount; ?>;
    const pending = <?php echo (int)$pendingCount; ?>;
    const complete = <?php echo (int)$completeCount; ?>;
    const notComplete = <?php echo (int)$notComplete; ?>;

    new Chart(document.getElementById('barChart'), {
        type: 'bar',
        data: {
            labels: ['Referred', 'Complete', 'Pending'],
            datasets: [{
                label: 'Count',
                data: [received, complete, pending],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    new Chart(document.getElementById('pieChart'), {
        type: 'pie',
        data: {
            labels: ['Complete', 'Not Complete'],
            datasets: [{
                data: [complete, notComplete],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true
        }
    });
</script>

<?php include __DIR__ . "/partials/layout_bottom.php"; ?>