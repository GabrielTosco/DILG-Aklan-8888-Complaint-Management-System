<?php
require 'auth.php';
require 'config.php';
require_once __DIR__ . '/audit.php';

// Only responders can upload resolution
if (($_SESSION['role'] ?? '') !== 'responder') {
    die("Access denied.");
}

$role = $_SESSION['role'] ?? 'viewer';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
    die("Invalid complaint ID.");
}

// Ensure complaint belongs to responder municipality
$stmt = $pdo->prepare("
    SELECT * FROM complaints
    WHERE id = ? AND municipality_id = ?
");
$stmt->execute([$id, $_SESSION['municipality_id']]);
$c = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$c) {
    die("Complaint not found or not assigned to your municipality.");
}

// 🔒 RULE 1: Must open/acknowledge the complaint first (received_at)
if (empty($c['received_at'])) {
    die("You must open/acknowledge the complaint before uploading a resolution.");
}

/*
✅ UPDATED RULES (overwrite allowed):
- If complaint is COMPLETE => block upload (only allowed again after encoder reopens => status becomes PENDING)
- If complaint is REFERRED or PENDING => allow upload and OVERWRITE old file
*/
if (($c['status'] ?? '') === 'COMPLETE') {
    die("This complaint is COMPLETE. You can only upload again if encoder requests revision.");
}

/* ✅ NEW: Load stacked revision history (for LGU to read) */
$revStmt = $pdo->prepare("
    SELECT rr.*, u.username, u.role
    FROM complaint_revision_requests rr
    JOIN users u ON u.id = rr.requested_by
    WHERE rr.complaint_id = ?
    ORDER BY rr.requested_at DESC
");
$revStmt->execute([$id]);
$revisionRequests = $revStmt->fetchAll(PDO::FETCH_ASSOC);

$error = "";
$success = "";

/* Helper: format datetime */
function fmt_dt_no_seconds($val)
{
    if (empty($val)) return '—';
    return date('Y-m-d h:i A', strtotime($val));
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    if (!isset($_FILES['resolution_pdf']) || $_FILES['resolution_pdf']['error'] !== UPLOAD_ERR_OK) {
        $error = "Please upload a PDF file.";
    } else {
        $fileTmp = $_FILES['resolution_pdf']['tmp_name'];
        $fileName = $_FILES['resolution_pdf']['name'];

        // PDF validation
        $ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        if ($ext !== 'pdf') {
            $error = "Only PDF files are allowed.";
        } else {

            $destFolder = __DIR__ . "/uploads/resolutions/";
            if (!is_dir($destFolder)) {
                mkdir($destFolder, 0777, true);
            }

            $newName = "resolution_" . $id . "_" . time() . ".pdf";
            $destPath = $destFolder . $newName;

            if (move_uploaded_file($fileTmp, $destPath)) {

                // ✅ OVERWRITE: delete old resolution if exists
                if (!empty($c['resolution_pdf_path']) && file_exists(__DIR__ . "/" . $c['resolution_pdf_path'])) {
                    @unlink(__DIR__ . "/" . $c['resolution_pdf_path']);
                }

                $publicPath = "uploads/resolutions/" . $newName;

                // Save new resolution.
                // If this complaint was previously FOR CORRECTION / REVISING,
                // the LGU has now resubmitted, so move it back to PENDING
                // for encoder review.
                $newStatus = 'PENDING';

                $upd = $pdo->prepare("
    UPDATE complaints
    SET resolution_pdf_path = ?,
        status = ?,
        resolved_by_user_id = ?,
        resolved_at = NOW(),
        updated_at = NOW()
    WHERE id = ?
");
                $upd->execute([
                    $publicPath,
                    $newStatus,
                    $_SESSION['user_id'],
                    $id
                ]);

                audit_log(
                    $pdo,
                    $id,
                    $_SESSION['user_id'],
                    'UPLOAD_RESOLUTION',
                    'Uploaded or replaced resolution PDF'
                );

                $success = (($c['status'] ?? '') === 'REVISING')
                    ? "Corrected resolution uploaded successfully. Status changed back to PENDING for encoder review."
                    : "Resolution uploaded successfully (overwritten).";

                // Refresh complaint data
                $stmt->execute([$id, $_SESSION['municipality_id']]);
                $c = $stmt->fetch(PDO::FETCH_ASSOC);

                // Refresh revision history too (optional)
                $revStmt->execute([$id]);
                $revisionRequests = $revStmt->fetchAll(PDO::FETCH_ASSOC);
            } else {
                $error = "Upload failed. Check folder permissions.";
            }
        }
    }
}

/* ✅ Page settings for global layout */
$pageTitle  = "Upload Resolution";
$activePage = "complaints";

/* ✅ Move page-specific CSS into extraHead */
$extraHead = <<<HTML
<style>
  .card {
    background: var(--card);
    border: 1px solid var(--line);
    border-radius: 12px;
    overflow: hidden;
  }

  .card-header {
    background: #1b2fbf;
    color: #fff;
    padding: 12px 14px;
    font-weight: 900;
    display: flex;
    align-items: center;
    justify-content: space-between;
  }

  .pad {
    padding: 14px;
  }

  .msg {
    padding: 10px 12px;
    border-radius: 10px;
    margin: 10px 0;
    border: 1px solid var(--line);
    font-weight: 700;
  }

  .msg.err {
    background: #ffecec;
    border-color: #ffbdbd;
    color: #b00020;
  }

  .msg.ok {
    background: #eafff2;
    border-color: #bff3cf;
    color: #0b6b2e;
  }

  .field {
    display: flex;
    flex-direction: column;
    gap: 8px;
    margin-top: 10px;
  }

  input[type="file"] {
    padding: 10px;
    border: 1px solid var(--line);
    border-radius: 10px;
    background: #fff;
  }

  .btn {
    display: inline-block;
    padding: 10px 14px;
    border-radius: 10px;
    background: var(--blue2);
    color: #fff;
    text-decoration: none;
    border: none;
    cursor: pointer;
    font-weight: 900;
  }

  .btn:hover {
    background: var(--blue);
  }

  .btn.secondary {
    background: #fff;
    color: #111;
    border: 1px solid var(--line);
  }

  .btn.secondary:hover {
    background: #f2f6ff;
  }

  .meta {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 10px;
    margin-top: 10px;
  }

  .meta div {
    background: #f8fbff;
    border: 1px solid var(--line);
    border-radius: 10px;
    padding: 10px;
  }

  .meta b {
    display: block;
    margin-bottom: 4px;
  }

  .hr {
    height: 1px;
    background: var(--line);
    margin: 14px 0;
  }

  /* ✅ Revision history box */
  .rev-wrap{
    background:#fff7ed;
    border:1px solid #fdba74;
    color:#9a3412;
    padding:12px 14px;
    border-radius:12px;
    margin-top:12px;
  }

  .rev-title{
    font-weight:900;
    margin-bottom:8px;
  }

  .rev-item{
    background:#fff;
    border:1px solid #fed7aa;
    border-radius:10px;
    padding:10px 12px;
    margin-bottom:10px;
    line-height:1.4;
    font-weight:800;
  }

  .rev-item:last-child{ margin-bottom:0; }

  .rev-meta{
    margin-top:8px;
    font-size:12px;
    font-weight:800;
    opacity:.95;
  }

  @media (max-width: 980px) {
    .meta {
      grid-template-columns: 1fr;
    }
  }
</style>
HTML;

/* ✅ include global header/sidebar */
include __DIR__ . "/partials/layout_top.php";
?>

<div class="card">
    <div class="card-header">
        <div>Resolution Upload</div>
        <a class="btn secondary" href="complaint_view.php?id=<?php echo (int)$id; ?>">← Back</a>
    </div>

    <div class="pad">
        <div class="meta">
            <div>
                <b>Tracking No</b>
                <?php echo htmlspecialchars($c['tracking_no'] ?? '—'); ?>
            </div>
            <div>
                <b>Nature of Call</b>
                <?php echo htmlspecialchars($c['nature_of_call'] ?? '—'); ?>
            </div>
        </div>

        <!-- ✅ STACKED REVISION HISTORY (instead of single remark) -->
        <?php if (!empty($revisionRequests) || !empty($c['revision_remarks'])): ?>
            <div class="rev-wrap">
                <div class="rev-title">Revision Remarks (History)</div>

                <?php if (!empty($revisionRequests)): ?>
                    <?php foreach ($revisionRequests as $rr): ?>
                        <div class="rev-item">
                            <?php echo nl2br(htmlspecialchars($rr['remarks'])); ?>
                            <div class="rev-meta">
                                Requested by: <b><?php echo htmlspecialchars($rr['username']); ?></b>
                                (<?php echo htmlspecialchars($rr['role']); ?>)
                                — <?php echo htmlspecialchars(fmt_dt_no_seconds($rr['requested_at'] ?? null)); ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <!-- Fallback: if history table has no rows yet but old field exists -->
                    <div class="rev-item">
                        <?php echo nl2br(htmlspecialchars($c['revision_remarks'])); ?>
                        <?php if (!empty($c['revision_requested_at'])): ?>
                            <div class="rev-meta">
                                Requested at: <?php echo htmlspecialchars(fmt_dt_no_seconds($c['revision_requested_at'])); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

            </div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="msg err"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="msg ok"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <form method="post" enctype="multipart/form-data"
            onsubmit="return confirm('Are you sure you want to upload this file?');">
            <div class="field">
                <label><b>Select PDF file</b></label>
                <input type="file" name="resolution_pdf" accept="application/pdf" required>
                <button class="btn" type="submit">Upload PDF</button>
            </div>
        </form>

        <div class="hr"></div>

        <div>
            <b>Current Resolution</b><br>
            <?php if (!empty($c['resolution_pdf_path'])): ?>
                <a class="btn secondary" href="<?php echo htmlspecialchars($c['resolution_pdf_path']); ?>" target="_blank">
                    Download Current PDF
                </a>
            <?php else: ?>
                —
            <?php endif; ?>
        </div>

    </div>
</div>

<?php
include __DIR__ . "/partials/layout_bottom.php";
?>