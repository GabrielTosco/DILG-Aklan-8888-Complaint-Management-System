<?php
require 'auth.php';
require 'config.php';

// Only encoder can view audit logs (recommended)
if ($_SESSION['role'] !== 'encoder') {
    die("Access denied.");
}

$complaint_id = isset($_GET['complaint_id']) ? (int)$_GET['complaint_id'] : 0;
if ($complaint_id <= 0) {
    die("Missing complaint_id.");
}

// Get complaint basic info
$cstmt = $pdo->prepare("
    SELECT c.id, c.tracking_no, c.subject, c.status, m.name AS municipality_name
    FROM complaints c
    JOIN municipalities m ON m.id = c.municipality_id
    WHERE c.id = ?
");
$cstmt->execute([$complaint_id]);
$c = $cstmt->fetch(PDO::FETCH_ASSOC);

if (!$c) {
    die("Complaint not found.");
}

// Load audit logs
$astmt = $pdo->prepare("
    SELECT a.*, u.username, u.role
    FROM audit_logs a
    JOIN users u ON u.id = a.user_id
    WHERE a.complaint_id = ?
    ORDER BY a.created_at ASC
");
$astmt->execute([$complaint_id]);
$logs = $astmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
  <title>Audit History</title>
</head>
<body>
  <p><a href="complaint_view.php?id=<?php echo (int)$complaint_id; ?>">← Back to complaint</a></p>

  <h2>Audit History</h2>

  <p><b>Complaint ID:</b> <?php echo htmlspecialchars($c['id']); ?></p>
  <p><b>Tracking No:</b> <?php echo htmlspecialchars($c['tracking_no'] ?? ''); ?></p>
  <p><b>Subject:</b> <?php echo htmlspecialchars($c['subject']); ?></p>
  <p><b>Municipality:</b> <?php echo htmlspecialchars($c['municipality_name']); ?></p>
  <p><b>Status:</b> <?php echo htmlspecialchars($c['status']); ?></p>

  <hr>

  <?php if (count($logs) === 0): ?>
    <p>No audit logs yet.</p>
  <?php else: ?>
    <table border="1" cellpadding="8" cellspacing="0">
      <tr>
        <th>Date/Time</th>
        <th>User</th>
        <th>Role</th>
        <th>Action</th>
        <th>Details</th>
      </tr>
      <?php foreach ($logs as $l): ?>
        <tr>
          <td><?php echo htmlspecialchars($l['created_at']); ?></td>
          <td><?php echo htmlspecialchars($l['username']); ?></td>
          <td><?php echo htmlspecialchars($l['role']); ?></td>
          <td><?php echo htmlspecialchars($l['action']); ?></td>
          <td><?php echo htmlspecialchars($l['details'] ?? ''); ?></td>
        </tr>
      <?php endforeach; ?>
    </table>
  <?php endif; ?>
</body>
</html>
