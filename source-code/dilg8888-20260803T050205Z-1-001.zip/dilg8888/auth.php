<?php
// dilg8888/auth.php
// ✅ Always use the Core session + auth so ALL apps share the same login.
require __DIR__ . '/../core/auth.php';
