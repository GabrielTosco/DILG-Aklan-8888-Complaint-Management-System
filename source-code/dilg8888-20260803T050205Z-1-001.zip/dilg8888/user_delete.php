<?php
require __DIR__ . "/auth.php";
require __DIR__ . "/config.php";

$role = $_SESSION["role"] ?? "viewer";
if ($role !== "encoder") {
  http_response_code(403);
  die("Forbidden");
}

// Basic CSRF token (same style used by other core pages)
if (!isset($_SESSION["csrf"])) {
  $_SESSION["csrf"] = bin2hex(random_bytes(16));
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
  http_response_code(405);
  die("Method not allowed");
}

$csrf = (string)($_POST["csrf"] ?? "");
if (!hash_equals($_SESSION["csrf"], $csrf)) {
  http_response_code(400);
  die("Bad request");
}

$id = (int)($_POST["id"] ?? 0);
if ($id <= 0) {
  http_response_code(400);
  die("Invalid user id");
}

// Prevent deleting own account (works whether you store user_id or not)
$myId = (int)($_SESSION["user_id"] ?? 0);
if ($myId > 0 && $id === $myId) {
  header("Location: /core/users_list.php?err=self");
  exit;
}

$stmt = $pdo->prepare("SELECT id, username FROM users WHERE id = ? LIMIT 1");
$stmt->execute([$id]);
$target = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$target) {
  header("Location: /core/users_list.php?err=notfound");
  exit;
}

if (($target["username"] ?? "") !== "" && ($target["username"] === ($_SESSION["username"] ?? ""))) {
  header("Location: /core/users_list.php?err=self");
  exit;
}

// ✅ Safer "delete": deactivate account (keeps records intact)
$up = $pdo->prepare("UPDATE users SET is_active = 0 WHERE id = ? LIMIT 1");
$up->execute([$id]);

header("Location: /core/users_list.php?ok=deleted");
exit;