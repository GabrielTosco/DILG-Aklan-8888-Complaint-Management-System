<?php
require 'auth.php';
require 'config.php';

$role = $_SESSION['role'] ?? 'viewer';
if ($role !== 'encoder') {
    http_response_code(403);
    die("Forbidden");
}

function h($s)
{
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

// fallback if missing
if (!function_exists('getDisplayRole')) {
    function getDisplayRole($r)
    {
        return htmlspecialchars((string)$r);
    }
}

// Load municipalities
$muniStmt = $pdo->query("SELECT id, name FROM municipalities ORDER BY name ASC");
$municipalities = $muniStmt->fetchAll(PDO::FETCH_ASSOC);

// Validate user id
$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    die("Invalid user id.");
}

// Fetch user
$stmt = $pdo->prepare("SELECT id, full_name, username, role, municipality_id, is_active, created_at
                       FROM users WHERE id = ? LIMIT 1");
$stmt->execute([$id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    die("User not found.");
}

$error = "";

// Handle update
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $full_name = trim($_POST["full_name"] ?? "");
    $username  = trim($_POST["username"] ?? "");
    $newRole   = trim($_POST["role"] ?? "");
    $municipality_id = (int)($_POST["municipality_id"] ?? 0);
    $is_active = isset($_POST["is_active"]) ? 1 : 0;

    // Optional password reset
    $new_password = $_POST["new_password"] ?? "";

    $needsFullName = ($newRole === "encoder");

    // ✅ If NOT encoder, force full_name blank (ignore whatever was posted)
    if (!$needsFullName) {
        $full_name = "";
    }

    if ($username === "" || $newRole === "") {
        $error = "Please fill in all required fields.";
    } elseif ($needsFullName && $full_name === "") {
        $error = "Full Name is required for encoder accounts.";
    } elseif (strlen($username) < 3) {
        $error = "Username must be at least 3 characters.";
    } else {
        // If not responder/mlgoo, force municipality null
        if ($newRole !== "responder" && $newRole !== "mlgoo") {
            $municipality_id = 0;
        }

        // Unique username check (exclude self)
        $chk = $pdo->prepare("SELECT id FROM users WHERE username = ? AND id <> ? LIMIT 1");
        $chk->execute([$username, $id]);
        if ($chk->fetchColumn()) {
            $error = "Username already exists.";
        } else {
            // Update with optional password
            if ($new_password !== "") {
                if (strlen($new_password) < 6) {
                    $error = "New password must be at least 6 characters.";
                } else {
                    $hash = password_hash($new_password, PASSWORD_BCRYPT);

                    $up = $pdo->prepare("
                        UPDATE users
                        SET full_name = ?,
                            username = ?,
                            role = ?,
                            municipality_id = ?,
                            is_active = ?,
                            password_hash = ?
                        WHERE id = ?
                    ");
                    $up->execute([
                        $full_name,
                        $username,
                        $newRole,
                        ($municipality_id > 0 ? $municipality_id : null),
                        $is_active,
                        $hash,
                        $id
                    ]);

                    header("Location: users_list.php");
                    exit;
                }
            } else {
                $up = $pdo->prepare("
                    UPDATE users
                    SET full_name = ?,
                        username = ?,
                        role = ?,
                        municipality_id = ?,
                        is_active = ?
                    WHERE id = ?
                ");
                $up->execute([
                    $full_name,
                    $username,
                    $newRole,
                    ($municipality_id > 0 ? $municipality_id : null),
                    $is_active,
                    $id
                ]);

                header("Location: users_list.php");
                exit;
            }
        }
    }

    // reflect posted values on error
    $user['full_name'] = $full_name;
    $user['username'] = $username;
    $user['role'] = $newRole;
    $user['municipality_id'] = ($newRole === 'responder' || $newRole === 'mlgoo') ? ($municipality_id ?: null) : null;
    $user['is_active'] = $is_active;
}

/* ✅ Page settings for global layout */
$pageTitle  = "Edit User - EP 8888";
$activePage = "users";

/* ✅ Move page-specific CSS into extraHead */
$extraHead = <<<HTML
<style>
  /* IMPORTANT:
     The global layout already provides body/app/sidebar/topbar/content styles in assets/css/layout.css
     So we REMOVE those and only keep page-specific styles below.
  */

  .card {
    background: var(--card);
    border: 1px solid var(--line);
    border-radius: 10px;
    overflow: hidden;
    padding: 16px;
  }

  h2 {
    margin: 8px 0 12px 0;
    text-align: center;
    font-size: 28px;
  }

  .row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
  }

  @media (max-width: 900px) {
    .row {
      grid-template-columns: 1fr;
    }
  }

  label {
    display: block;
    font-size: 13px;
    color: #374151;
    font-weight: 800;
    margin-bottom: 6px;
  }

  input,
  select {
    width: 100%;
    padding: 12px 12px;
    border: 1px solid var(--line);
    border-radius: 10px;
    outline: none;
    background: #fff;
  }

  .btn {
    display: inline-block;
    padding: 10px 14px;
    border-radius: 10px;
    background: #fff;
    border: 1px solid var(--line);
    text-decoration: none;
    color: #111;
    font-weight: 900;
    cursor: pointer;
  }

  .btn:hover {
    background: #f2f6ff;
  }

  .btn.primary {
    background: #0a4aa6;
    border-color: #0a4aa6;
    color: #fff;
  }

  .btn.gray {
    background: #334155;
    border-color: #334155;
    color: #fff;
  }

  .muted-sm {
    color: #6b7280;
    font-size: 13px;
    font-weight: 700;
  }

  .err {
    background: #fee2e2;
    border: 1px solid #fecaca;
    color: #991b1b;
    padding: 10px 12px;
    border-radius: 10px;
    margin: 12px 0;
    font-weight: 800;
  }

  .meta {
    display: flex;
    gap: 14px;
    flex-wrap: wrap;
    margin-top: 6px;
  }

  .meta div {
    font-size: 13px;
    color: #6b7280;
    font-weight: 700;
  }
</style>
HTML;

/* ✅ include global header/sidebar */
include __DIR__ . "/partials/layout_top.php";
?>

<div class="card">
    <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;">
        <div>
            <h2 style="margin:0;text-align:left;">Edit Account</h2>
            <div class="meta">
                <div>User ID: <?php echo (int)$user['id']; ?></div>
                <div>Created: <?php echo h($user['created_at']); ?></div>
            </div>
        </div>
        <a class="btn gray" href="users_list.php">← Back</a>
    </div>

    <?php if ($error): ?>
        <div class="err"><?php echo h($error); ?></div>
    <?php endif; ?>

    <form method="POST" style="margin-top:12px;">
        <div class="row">

            <!-- ✅ Full Name editable only if role = encoder -->
            <div id="fullNameWrap">
                <label>Full Name (encoder only) *</label>
                <input id="fullNameInput" name="full_name" value="<?php echo h($user['full_name']); ?>">
            </div>

            <div>
                <label>Username *</label>
                <input name="username" value="<?php echo h($user['username']); ?>" required>
            </div>

            <div>
                <label>Role *</label>
                <select name="role" id="roleSel" required>
                    <?php
                    $roles = ["encoder", "responder", "mlgoo"];
                    foreach ($roles as $r):
                        $sel = ($user['role'] === $r) ? "selected" : "";
                    ?>
                        <option value="<?php echo h($r); ?>" <?php echo $sel; ?>>
                            <?php echo h($r); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <label>Municipality (for responder/mlgoo only)</label>
                <select name="municipality_id" id="muniSel">
                    <option value="0">-- None --</option>
                    <?php foreach ($municipalities as $m): ?>
                        <?php
                        $mid = (int)$m['id'];
                        $sel = ((int)($user['municipality_id'] ?? 0) === $mid) ? "selected" : "";
                        ?>
                        <option value="<?php echo $mid; ?>" <?php echo $sel; ?>>
                            <?php echo h($m['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <label>New Password (leave blank if no change)</label>
                <input type="password" name="new_password" placeholder="••••••••">
                <div class="muted-sm">Min 6 characters</div>
            </div>

            <div style="display:flex;align-items:end;gap:10px;">
                <label style="display:flex;align-items:center;gap:8px;font-weight:800;margin:0;">
                    <input type="checkbox" name="is_active" <?php echo ((int)$user['is_active'] === 1) ? "checked" : ""; ?> style="width:auto;">
                    Active
                </label>
            </div>
        </div>

        <div style="margin-top:14px;display:flex;gap:10px;justify-content:center;flex-wrap:wrap;">
            <button class="btn primary" type="submit">💾 Save Changes</button>
        </div>
    </form>
</div>

<script>
    const roleSel = document.getElementById('roleSel');
    const muniSel = document.getElementById('muniSel');

    const fullNameWrap = document.getElementById('fullNameWrap');
    const fullNameInput = document.getElementById('fullNameInput');

    function syncMuni() {
        const r = roleSel.value;
        const needsMuni = (r === 'responder' || r === 'mlgoo');
        muniSel.disabled = !needsMuni;
        if (!needsMuni) muniSel.value = "0";
    }

    function syncFullName() {
        const needs = (roleSel.value === 'encoder');
        fullNameWrap.style.display = needs ? '' : 'none';
        fullNameInput.required = needs;
        if (!needs) fullNameInput.value = '';
    }

    roleSel.addEventListener('change', () => { syncMuni(); syncFullName(); });
    syncMuni();
    syncFullName();
</script>

<?php
/* ✅ include global footer/scripts */
include __DIR__ . "/partials/layout_bottom.php";
?>