<?php
require 'auth.php';
require 'config.php';
require_once __DIR__ . '/audit.php';

$role = $_SESSION['role'] ?? 'viewer';
if ($role !== 'encoder') die("Access denied.");

$error = "";
$success = "";

// Fetch municipalities for dropdown
$muniStmt = $pdo->query("SELECT id, name FROM municipalities ORDER BY name ASC");
$municipalities = $muniStmt->fetchAll(PDO::FETCH_ASSOC);

function to_mysql_datetime_from_local($val)
{
  if (empty($val)) return null;
  $ts = strtotime($val);
  if (!$ts) return null;
  return date('Y-m-d H:i:s', $ts);
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {

  // ✅ Fields (none are strict except municipality + pdf)
  $tracking_no      = trim($_POST['tracking_no'] ?? '');
  $subject          = trim($_POST['subject'] ?? '');
  $nature_of_call   = trim($_POST['nature_of_call'] ?? '');
  $focal_person     = trim($_POST['focal_person'] ?? '');        // stored in DB column "complainant"
  $client_name      = trim($_POST['client_name'] ?? '');
  $address          = trim($_POST['address'] ?? '');
  $contact_details  = trim($_POST['contact_details'] ?? '');

  $date_sent_local  = trim($_POST['date_sent'] ?? '');
  $date_sent        = to_mysql_datetime_from_local($date_sent_local); // optional
  $municipality_id  = (int)($_POST['municipality_id'] ?? 0);


  // Required checks
  if ($tracking_no === '') {
    $error = "Please enter the Ticket Reference Number.";
  } elseif ($subject === '') {
    $error = "Please enter the Subject.";
  } elseif ($nature_of_call === '') {
    $error = "Please enter the Nature of Call.";
  } elseif ($focal_person === '') {
    $error = "Please enter the Focal Person.";
  } elseif ($municipality_id <= 0) {
    $error = "Please select a municipality.";
  } elseif (!isset($_FILES['complaint_pdf']) || $_FILES['complaint_pdf']['error'] !== UPLOAD_ERR_OK) {
    $error = "Please upload the complaint PDF file.";
  } else {

    // ✅ STOP crash: block duplicate tracking number BEFORE uploading/saving
    if ($tracking_no !== '') {
      $dup = $pdo->prepare("SELECT 1 FROM complaints WHERE tracking_no = ? LIMIT 1");
      $dup->execute([$tracking_no]);

      if ($dup->fetchColumn()) {
        $error = "Tracking number already exists.";
      }
    }

    // ✅ Only continue if no error
    if (!$error) {
      $ext = strtolower(pathinfo($_FILES['complaint_pdf']['name'], PATHINFO_EXTENSION));
      if ($ext !== 'pdf') {
        $error = "Only PDF files are allowed.";
      } else {

        $destFolder = __DIR__ . "/uploads/complaints/";
        if (!is_dir($destFolder)) mkdir($destFolder, 0777, true);

        $newName = "complaint_" . time() . ".pdf";
        $destPath = $destFolder . $newName;

        if (move_uploaded_file($_FILES['complaint_pdf']['tmp_name'], $destPath)) {

          $publicPath = "uploads/complaints/" . $newName;

          // ✅ date_sent: if blank use NOW()
          if ($date_sent) {
            $ins = $pdo->prepare("
                        INSERT INTO complaints
                        (tracking_no, subject, nature_of_call, complainant, client_name, address, contact_details,
                         date_sent, status, municipality_id, complaint_pdf_path, encoded_by_user_id)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'REFERRED', ?, ?, ?)
                    ");
            $ins->execute([
              ($tracking_no !== '' ? $tracking_no : null),
              $subject,
              ($nature_of_call !== '' ? $nature_of_call : null),
              ($focal_person !== '' ? $focal_person : null),
              ($client_name !== '' ? $client_name : null),
              ($address !== '' ? $address : null),
              ($contact_details !== '' ? $contact_details : null),
              $date_sent,
              $municipality_id,
              $publicPath,
              $_SESSION['user_id']
            ]);
          } else {
            $ins = $pdo->prepare("
                        INSERT INTO complaints
                        (tracking_no, subject, nature_of_call, complainant, client_name, address, contact_details,
                         date_sent, status, municipality_id, complaint_pdf_path, encoded_by_user_id)
                        VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), 'REFERRED', ?, ?, ?)
                    ");
            $ins->execute([
              ($tracking_no !== '' ? $tracking_no : null),
              $subject,
              ($nature_of_call !== '' ? $nature_of_call : null),
              ($focal_person !== '' ? $focal_person : null),
              ($client_name !== '' ? $client_name : null),
              ($address !== '' ? $address : null),
              ($contact_details !== '' ? $contact_details : null),
              $municipality_id,
              $publicPath,
              $_SESSION['user_id']
            ]);
          }

          $newComplaintId = $pdo->lastInsertId();
          audit_log($pdo, $newComplaintId, $_SESSION['user_id'], 'ADD_COMPLAINT', 'Added complaint + uploaded PDF');

          $success = "Complaint added successfully!";
          $_POST = [];
        } else {
          $error = "Upload failed. Check folder permissions.";
        }
      } // ✅ closes: if (!$error)
    }
  }
}

/* ✅ Page settings for global layout */
$pageTitle  = "Citizen Complaints Monitoring - Add Complaint";
$activePage = "add_complaint";

$extraHead = <<<HTML
<style>
  .req {
  color: red;
}
  h2 { margin:8px 0 12px 0; text-align:center; font-size:28px; }
  .card { background: var(--card); border: 1px solid var(--line); border-radius: 10px; overflow: hidden; }
  .card-header { background: #1b2fbf; color: #fff; padding: 10px 12px; font-weight: 900; }
  .pad { padding: 12px; }
  .btn { display:inline-block; padding:10px 14px; border-radius:10px; background:#fff; border:1px solid var(--line); text-decoration:none; color:#111; font-weight:900; cursor:pointer; }
  .btn:hover { background:#f2f6ff; }
  .btn-primary { background:#111; color:#fff; border:1px solid #111; }
  .btn-primary:hover { opacity:.9; background:#111; color:#fff; }
  .alert { padding:10px 12px; border-radius:10px; margin:10px 0; border:1px solid var(--line); background:#fff; font-weight:800; }
  .alert.ok { border-color:#b7ebc6; background:#e8fff1; }
  .alert.err { border-color:#f2b8b8; background:#ffecec; }
  label { font-weight:500; }
  input[type="text"], input[type="datetime-local"], select, textarea {
    width:100%; padding:10px 10px; border:1px solid var(--line); border-radius:10px; font-size:14px; background:#fff;
    font-family: inherit;
    box-sizing: border-box;
  }
  textarea {
    resize: vertical;
    min-height: 100px;
    line-height: 1.5;
  }
  input[type="file"] { width:100%; padding:10px 10px; border:1px solid var(--line); border-radius:10px; background:#fff; }
  .row { margin-bottom:12px; }
  .mini { font-size:12px; color:#6b7280; margin-top:6px; padding-left:10px;}
  .top-actions { display:flex; gap:10px; justify-content:center; flex-wrap:wrap; margin-bottom:12px; }
</style>
HTML;

include __DIR__ . "/partials/layout_top.php";
?>

<h2>Add Complaint</h2>

<?php if ($error): ?>
  <div class="alert err"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>
<?php if ($error === "Tracking number already exists."): ?>
  <script>
    alert("⚠ Tracking number already exists!");
  </script>
<?php endif; ?>

<?php if ($success): ?>
  <div class="alert ok"><?php echo htmlspecialchars($success); ?></div>
  <div class="top-actions">
    <a class="btn btn-primary" href="complaints_list.php">Go to Complaints List</a>
  </div>
<?php endif; ?>

<div class="card">

  <div class="card-header">Encoder Form</div>
  <div class="mini">Please fill in all fields marked with *. Optional fields it will be saved as N/A.</div>
  <div class="pad">
    <form method="post" enctype="multipart/form-data" onsubmit="return confirm('Are you sure you want to save this complaint?');">

      <div class="row">
        <label>Ticket Reference Number <span class="req">*</span></label><br>
        <input type="text" name="tracking_no" value="<?php echo htmlspecialchars($_POST['tracking_no'] ?? ''); ?>" required>
      </div>

      <div class="row">
        <label>Date</label><br>
        <input type="datetime-local" name="date_sent" value="<?php echo htmlspecialchars($_POST['date_sent'] ?? ''); ?>">
        <div class="mini">If blank, system uses current date/time.</div>
      </div>

      <div class="row">
        <label>Nature of Call <span class="req">*</span></label><br>
        <input type="text" name="nature_of_call" value="<?php echo htmlspecialchars($_POST['nature_of_call'] ?? ''); ?>" required>
      </div>

      <div class="row">
        <label>Subject <span class="req">*</span></label><br>
        <textarea name="subject" rows="4" required><?php echo htmlspecialchars($_POST['subject'] ?? ''); ?></textarea>
      </div>

      <div class="row">
        <label>Focal Person <span class="req">*</span></label><br>
        <input type="text" name="focal_person" value="<?php echo htmlspecialchars($_POST['focal_person'] ?? ''); ?>" required>
      </div>

      <div class="row">
        <label>Name of Client (optional)</label><br>
        <input type="text" name="client_name" value="<?php echo htmlspecialchars($_POST['client_name'] ?? ''); ?>">
      </div>

      <div class="row">
        <label>Address (optional)</label><br>
        <input type="text" name="address" value="<?php echo htmlspecialchars($_POST['address'] ?? ''); ?>">
      </div>

      <div class="row">
        <label>Contact Details (optional)</label><br>
        <input type="text" name="contact_details" value="<?php echo htmlspecialchars($_POST['contact_details'] ?? ''); ?>">
      </div>

      <div class="row">
        <label>Assign Municipality <span class="req">*</span></label><br>
        <select name="municipality_id" required>
          <option value="">-- Select Municipality --</option>
          <?php foreach ($municipalities as $m): ?>
            <option value="<?php echo (int)$m['id']; ?>"
              <?php
              $posted = (int)($_POST['municipality_id'] ?? 0);
              if ($posted === (int)$m['id']) echo 'selected';
              ?>>
              <?php echo htmlspecialchars($m['name']); ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="row">
        <label>Complaint PDF <span class="req">*</span></label><br>
        <input type="file" name="complaint_pdf" accept="application/pdf" required>
      </div>

      <button class="btn btn-primary" type="submit">Save Complaint</button>
    </form>
  </div>
</div>

<?php include __DIR__ . "/partials/layout_bottom.php"; ?>