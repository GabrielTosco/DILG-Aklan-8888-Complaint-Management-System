<?php
require 'auth.php';
require 'config.php';
require_once __DIR__ . '/audit.php';

$role = $_SESSION['role'] ?? 'viewer';
if ($role !== 'encoder') {
  die("Access denied.");
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) die("Invalid complaint ID.");

// Fetch complaint (encoder can view all)
$stmt = $pdo->prepare("
    SELECT c.*, m.name AS municipality_name
    FROM complaints c
    JOIN municipalities m ON m.id = c.municipality_id
    WHERE c.id = ?
");
$stmt->execute([$id]);
$c = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$c) die("Complaint not found.");
// ✅ Block revision request if there is no resolution PDF uploaded yet
if (empty($c['resolution_pdf_path']) || trim((string)$c['resolution_pdf_path']) === '') {
  header("Location: complaint_view.php?id=" . (int)$id . "&err=" . urlencode("Cannot request revision: no resolution PDF uploaded yet."));
  exit;
}

$error = "";
$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $remarks = trim($_POST['revision_remarks'] ?? '');

  if ($remarks === '') {
    $error = "Remarks are required.";
  } else {

    // ✅ 1) STACKABLE: insert a new revision request record
    $ins = $pdo->prepare("
            INSERT INTO complaint_revision_requests (complaint_id, requested_by, remarks)
            VALUES (?, ?, ?)
        ");
    $ins->execute([$id, $_SESSION['user_id'], $remarks]);

    // ✅ 2) Keep your existing workflow intact:
    //    - set status back to PENDING
    //    - update the latest fields for backwards-compat (optional but recommended)
    $upd = $pdo->prepare("
        UPDATE complaints
        SET status = 'REVISING',
            revision_remarks = ?,
            revision_requested_by = ?,
            revision_requested_at = NOW(),
            updated_at = NOW()
        WHERE id = ?
    ");
    $upd->execute([$remarks, $_SESSION['user_id'], $id]);

    audit_log(
      $pdo,
      $id,
      $_SESSION['user_id'],
      'REQUEST_REVISION',
      'Requested revision (stacked): ' . mb_substr($remarks, 0, 200)
    );

    header("Location: complaint_view.php?id=" . $id . "&msg=" . urlencode("Revision requested. Remarks sent to LGU."));
    exit;
  }
}

/* Page settings for your global layout */
$pageTitle  = "Request Revision - Encoder Remarks";
$activePage = "complaints";

$extraHead = <<<HTML
<style>
  h2{ margin:0 0 16px; font-size:28px; }
  .card{ background:var(--card); border-radius:10px; box-shadow:0 2px 8px rgba(0,0,0,.08); }
  .card-header{ padding:16px 20px; border-bottom:1px solid var(--line); font-weight:700; }
  .pad{ padding:20px; }
  .alert{ padding:12px 16px; border-radius:8px; margin-bottom:12px; border:1px solid var(--line); background:#f9fafb; }
  .alert.err{ background:#fee2e2; border-color:#fca5a5; color:#991b1b; }
  .alert.ok{ background:#d1fae5; border-color:#6ee7b7; color:#065f46; }
  textarea{
    width:100%;
    padding:12px 14px;
    border:1px solid #ccc;
    border-radius:8px;
    font-size:14px;
    resize:vertical;
    font-family:Arial, Helvetica, sans-serif;
  }
  textarea:focus{ outline:none; border-color:var(--blue); }
  .btn{
    display:inline-block; padding:10px 18px; border-radius:8px;
    border:none; cursor:pointer; text-decoration:none;
    background:var(--blue); color:#fff; font-weight:600;
  }
  .btn:hover{ background:var(--blue2); }
  .btn-ghost{ background:#e5e7eb; color:#111827; }
  .btn-ghost:hover{ background:#d1d5db; }
</style>
HTML;

include __DIR__ . "/partials/layout_top.php";
?>

<h2>Request Revision (Encoder Remarks)</h2>

<div style="margin-bottom:12px;">
  <a class="btn btn-ghost" href="complaint_view.php?id=<?php echo (int)$id; ?>">← Back to Complaint</a>
</div>

<?php if ($error): ?>
  <div class="alert err"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<div class="card">
  <div class="card-header">
    Complaint: <?php echo htmlspecialchars($c['tracking_no'] ?? '—'); ?> — <?php echo htmlspecialchars($c['municipality_name']); ?>
  </div>
  <div class="pad">
    <div class="alert">
      Write clearly why you want a revision. This message will be visible to the LGU.
      Each submission becomes a new entry in the remarks history.
    </div>

    <form method="post" onsubmit="return confirm('Send these remarks to LGU and request revision?');">
      <label style="font-weight:800; display:block; margin-bottom:8px;">Revision Remarks</label>

      <!-- ✅ Keep textarea blank so encoder writes a NEW remark every time -->
      <textarea name="revision_remarks" rows="6" required></textarea>

      <div style="height:12px;"></div>

      <button class="btn" type="submit">Send Remarks & Request Revision</button>
    </form>
  </div>
</div>

<?php include __DIR__ . "/partials/layout_bottom.php"; ?>