<?php
require 'auth.php';
require 'config.php';

$role = $_SESSION['role'] ?? 'viewer';

$search = trim($_GET['search'] ?? '');
$status = $_GET['status'] ?? 'ALL';
$municipality_filter = $_GET['municipality_id'] ?? 'ALL';

/* ✅ AJAX mode flag (returns ONLY <tbody> rows HTML) */
$isAjax = isset($_GET['ajax']) && $_GET['ajax'] == '1';

// Fetch municipalities for dropdown
$muniStmt = $pdo->query("SELECT id, name FROM municipalities ORDER BY name ASC");
$municipalities = $muniStmt->fetchAll(PDO::FETCH_ASSOC);

// Base SQL
$sql = "
    SELECT c.*, m.name AS municipality_name
    FROM complaints c
    JOIN municipalities m ON m.id = c.municipality_id
";
$params = [];
$conditions = [];

// Role restriction: responder only sees their municipality
if ($role === 'responder' || $role === 'mlgoo') {
    $conditions[] = "c.municipality_id = ?";
    $params[] = $_SESSION['municipality_id'];
} else {
    if ($municipality_filter !== 'ALL') {
        $mid = (int)$municipality_filter;
        if ($mid > 0) {
            $conditions[] = "c.municipality_id = ?";
            $params[] = $mid;
        }
    }
}

// Status filter
if ($status !== 'ALL') {
    $conditions[] = "c.status = ?";
    $params[] = $status;
}

// ✅ Search (includes ticket, subject, nature of call, focal person, client info)
if ($search !== '') {
    $conditions[] = "(
        c.tracking_no LIKE ?
        OR c.subject LIKE ?
        OR c.nature_of_call LIKE ?
        OR c.complainant LIKE ?
        OR c.client_name LIKE ?
        OR c.address LIKE ?
        OR c.contact_details LIKE ?
    )";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if (count($conditions) > 0) {
    $sql .= " WHERE " . implode(" AND ", $conditions);
}

$sql .= " ORDER BY c.created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$complaints = $stmt->fetchAll(PDO::FETCH_ASSOC);

if ($role === 'responder' || $role === 'mlgoo'){
    $municipality_filter = (string)($_SESSION['municipality_id'] ?? 'ALL');
}

// Helper format
function fmt_dt_no_seconds($val)
{
    if (empty($val)) return '—';
    return date('Y-m-d h:i A', strtotime($val));
}

// Calculate elapsed time between date_sent and resolved_at
function calculate_elapsed_time($date_sent, $resolved_at)
{
    if (empty($date_sent) || empty($resolved_at)) {
        return '—';
    }

    $start = new DateTime($date_sent);
    $end = new DateTime($resolved_at);
    $interval = $start->diff($end);

    $days = $interval->days;

    if ($days == 0) {
        return 'Same day';
    } elseif ($days == 1) {
        return '1 day';
    } else {
        return $days . ' days';
    }
}

/* ✅ Page settings for global layout */
$pageTitle  = "Citizen Complaints Monitoring - Complaints List";
$activePage = "complaints";

/* ✅ CSS (your same CSS + ONLY added clamp + fixed layout rules) */

/* ✅ Render ONLY table rows (for normal load + AJAX filtering) */
function renderComplaintRows(array $complaints, string $role): string
{
    ob_start();
    ?>

        <?php if (count($complaints) === 0): ?>
          <tr>
            <td colspan="10">No matching complaints.</td>
          </tr>
        <?php else: ?>
          <?php foreach ($complaints as $c): ?>
            <?php
              $st = strtoupper($c['status']);
              // ✅ UI label only (keep DB value as REVISING)
              $stDisplay = ($st === 'REVISING') ? 'FOR CORRECTION' : $st;
              $stClass = $st === 'COMPLETE' ? 'st-complete'
              : ($st === 'PENDING' ? 'st-pending'
              : ($st === 'REVISING' ? 'st-revising'
              : 'st-received'));

              /* ===== AGE COLOR LOGIC (ONLY if NOT COMPLETE) ===== */
              $rowClass = "";
              $days_old = 0;

              // ✅ Stop coloring once complaint is COMPLETE
              if ($st !== 'COMPLETE') {
                  if (!empty($c['date_sent'])) {
                      $dateSent = new DateTime($c['date_sent']);
                      $today = new DateTime();
                      $interval = $today->diff($dateSent);
                      $days_old = $interval->days;
                  }

                  if ($days_old >= 3) {
                      $rowClass = "row-red";
                  } elseif ($days_old == 2) {
                      $rowClass = "row-yellow";
                  }
              }

              // responder dropdown only if reopened (pending + has existing resolution)
              $isReopenedForResponder = (
                  ($role === 'responder') &&
                  (($c['status'] === 'PENDING') || ($c['status'] === 'REVISING')) &&
                  (!empty($c['resolution_pdf_path']))
              );
            ?>
            <tr class="<?php echo $rowClass; ?>">
              <td class="col-ticket">
                <span class="clamp-1"><?php echo htmlspecialchars($c['tracking_no'] ?? ''); ?></span>
              </td>

              <td class="col-nature">
                <span class="clamp-2"><?php echo htmlspecialchars($c['nature_of_call'] ?? ''); ?></span>
              </td>

              <td>
                <span class="clamp-1"><?php echo htmlspecialchars($c['municipality_name']); ?></span>
              </td>

              <td><span class="status-pill <?php echo $stClass; ?>"><?php echo htmlspecialchars($stDisplay); ?></span></td>

              <td><span class="clamp-1"><?php echo htmlspecialchars(fmt_dt_no_seconds($c['date_sent'] ?? null)); ?></span></td>
              <td><span class="clamp-1"><?php echo htmlspecialchars(fmt_dt_no_seconds($c['resolved_at'] ?? null)); ?></span></td>
              <td><span class="clamp-1"><?php echo htmlspecialchars(calculate_elapsed_time($c['date_sent'] ?? null, $c['resolved_at'] ?? null)); ?></span></td>

              <td>
                <a class="small-link" href="<?php echo htmlspecialchars($c['complaint_pdf_path']); ?>" target="_blank">Open</a>
              </td>

              <td>
                <?php if (!empty($c['resolution_pdf_path'])): ?>
                  <a class="small-link" href="<?php echo htmlspecialchars($c['resolution_pdf_path']); ?>" target="_blank">Open</a>
                <?php else: ?>
                  —
                <?php endif; ?>
              </td>

              <td>
                <?php if ($role === 'encoder'): ?>
                  <select class="action" onchange="if(this.value) window.location.href=this.value;">
                    <option value="" selected disabled hidden>Action</option>
                    <option value="complaint_view.php?id=<?php echo (int)$c['id']; ?>">View</option>
                    <option value="complaint_edit.php?id=<?php echo (int)$c['id']; ?>">Edit</option>
                    <option value="complaint_delete.php?id=<?php echo (int)$c['id']; ?>">Delete</option>
                  </select>

                <?php elseif ($role === 'responder'): ?>

                  <?php if ($isReopenedForResponder): ?>
                    <select class="action" onchange="if(this.value) window.location.href=this.value;">
                      <option value="" selected disabled hidden>Action</option>
                      <option value="complaint_view.php?id=<?php echo (int)$c['id']; ?>">View</option>
                      <option value="resolution_upload.php?id=<?php echo (int)$c['id']; ?>">Edit (Replace PDF)</option>
                    </select>
                  <?php else: ?>
                    <a class="small-link" href="complaint_view.php?id=<?php echo (int)$c['id']; ?>">View</a>
                  <?php endif; ?>

                <?php else: ?>
                  <a class="small-link" href="complaint_view.php?id=<?php echo (int)$c['id']; ?>">View</a>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      
  
    <?php
    return ob_get_clean();
}

/* ✅ If called via AJAX, return ONLY <tr> rows (no layout/sidebar) */
if ($isAjax) {
    header("Content-Type: text/html; charset=utf-8");
    echo renderComplaintRows($complaints, (string)$role);
    exit;
}

$extraHead = <<<HTML
<style>
  h2 {
    color: #222;
    font-size: 28px;
    margin: 0 0 20px;
  }

  .quick-links {
    margin-bottom: 20px;
  }

  .btn {
    display: inline-block;
    padding: 10px 18px;
    background: var(--blue);
    color: #fff;
    text-decoration: none;
    border-radius: 6px;
    font-size: 14px;
    transition: background .2s;
  }

  .btn:hover {
    background: var(--blue2);
  }

  .card {
    background: var(--card);
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, .08);
    margin-bottom: 20px;
  }

  .card-header {
    padding: 16px 20px;
    border-bottom: 1px solid var(--line);
    font-weight: bold;
    font-size: 16px;
  }

  .pad {
    padding: 20px;
  }

  .filters {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 16px;
    align-items: end;
  }

  .filters label {
    display: block;
    margin-bottom: 6px;
    font-size: 14px;
    font-weight: 600;
    color: #333;
  }

  .filters input,
  .filters select {
    width: 100%;
    padding: 8px 12px;
    border: 1px solid #ccc;
    border-radius: 6px;
    font-size: 14px;
    background: #fff;
  }

  .actions {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
  }

  .actions button {
    padding: 10px 20px;
    background: var(--blue);
    color: #fff;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
    transition: background .2s;
  }

  .actions button:hover {
    background: var(--blue2);
  }

  .reset {
    padding: 10px 20px;
    background: #6b7280;
    color: #fff;
    text-decoration: none;
    border-radius: 6px;
    display: inline-flex;
    align-items: center;
    font-size: 14px;
    transition: background .2s;
  }

  .reset:hover {
    background: #4b5563;
  }

  /* ✅ Keep table width stable */
  table {
    width: 100%;
    border-collapse: collapse;
    font-size: 14px;
    table-layout: fixed; /* ✅ prevents column width from changing per row */
  }

  th{
    text-align:left;
    padding:12px 7px;
    background:#f9fafb;
    font-weight:600;
    color:#374151;
    border-bottom:2px solid var(--line);

    /* ✅ FIX: allow header text to wrap instead of overflowing into the next column */
    white-space: normal;
    overflow-wrap: anywhere;
    line-height: 1.15;
  }
  td {
    padding: 12px 10px;
    border-bottom: 1px solid var(--line);
    vertical-align: top;
    overflow: hidden;
  }

  tr:hover {
    background: #f9fafb;
  }

  .status-pill {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 600;
  }

  .st-complete {
    background: #d1fae5;
    color: #065f46;
  }

  .st-pending {
    background: #fef3c7;
    color: #92400e;
  }
  .st-revising {
    background: #fee2e2;
    color: #991b1b;
  }
  .st-received {
    background: #dbeafe;
    color: #1e40af;
  }

  .small-link {
    color: var(--blue);
    text-decoration: none;
    font-size: 13px;
    font-weight: 700;
  }

  .small-link:hover {
    text-decoration: underline;
  }

  .action {
    padding: 6px 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
    font-size: 13px;
    cursor: pointer;
    background: #fff;
  }

  .row-red {
    background-color: #fee2e2 !important;
  }

  .row-yellow {
    background-color: #fef3c7 !important;
  }

  /* ✅ Clamp text so row height stays consistent */
  /* ✅ clamp ONLY for cell contents */
  .clamp-1{
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    display:block;
    max-width:100%;
  }
  .clamp-2{
    display:-webkit-box;
    -webkit-box-orient:vertical;
    -webkit-line-clamp:2;
    overflow:hidden;
    word-break: break-word;
  }

  /* Optional: make the key columns a bit wider (still fixed layout) */
  th.col-ticket, td.col-ticket { width: 160px; }
  th.col-nature, td.col-nature { width: 200px; }

  .table-dim { opacity: .55; pointer-events:none; }

  @media (max-width: 768px) {
    .filters {
      grid-template-columns: 1fr;
    }
    .pad {
      overflow: auto;
    }
    th.col-nature, td.col-nature { width: 220px; }
  }
</style>
HTML;

/* ✅ include global header/sidebar */
include __DIR__ . "/partials/layout_top.php";
?>

<h2>Complaints List</h2>

<div class="card">
  <div class="card-header">Filters</div>
  <div class="pad">
    <form method="get" id="filtersForm" autocomplete="off">
      <div class="filters">
        <div>
          <label>Search</label>
          <input type="text" id="searchInput" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="ticket ref / nature / focal person / etc.">
        </div>

        <div>
          <label>Status</label>
          <select id="statusSelect" name="status">
            <option value="ALL" <?php if ($status === 'ALL') echo 'selected'; ?>>ALL</option>
            <option value="REFERRED" <?php if ($status === 'REFERRED') echo 'selected'; ?>>REFERRED</option>
            <option value="PENDING" <?php if ($status === 'PENDING') echo 'selected'; ?>>PENDING</option>
            <option value="COMPLETE" <?php if ($status === 'COMPLETE') echo 'selected'; ?>>COMPLETE</option>
            <option value="REVISING" <?php if ($status === 'REVISING') echo 'selected'; ?>>FOR CORRECTION</option>
          </select>
        </div>

        <div>
          <label>Municipality</label>
          <select id="muniSelect" name="municipality_id" <?php if ($role === 'responder' || $role === 'mlgoo') echo 'disabled'; ?>>
            <option value="ALL" <?php if ($municipality_filter === 'ALL') echo 'selected'; ?>>ALL</option>
            <?php foreach ($municipalities as $m): ?>
              <?php $mid = (string)$m['id']; ?>
              <option value="<?php echo (int)$m['id']; ?>" <?php if ($municipality_filter === $mid) echo 'selected'; ?>>
                <?php echo htmlspecialchars($m['name']); ?>
              </option>
            <?php endforeach; ?>
          </select>

          <?php if ($role === 'responder' || $role === 'mlgoo'): ?>
            <input type="hidden" name="municipality_id" value="<?php echo (int)$_SESSION['municipality_id']; ?>">
          <?php endif; ?>
        </div>

        <div class="actions">
          <button type="submit">Apply</button>
          <a class="reset" href="complaints_list.php">Reset</a>
        </div>
      </div>
    </form>
  </div>
</div>

<div class="card">
  <div class="card-header">Results</div>
  <div class="pad" style="overflow:auto;">
    <table id="resultsTable">
      <thead>
        <tr>
          <th class="col-ticket">Ticket Reference Number</th>
          <th class="col-nature">Nature of Call</th>
          <th>Municipality</th>
          <th>Status</th>
          <th>Date Sent</th>
          <th>Date Responded</th>
          <th>Elapsed Time</th>
          <th>Complaint File</th>
          <th>Respond File</th>
          <th>Action</th>
        </tr>
      </thead>

      <tbody id="resultsTbody">
        <?php echo renderComplaintRows($complaints, (string)$role); ?>
      </tbody>
    </table>
  </div>
</div>

<script>
(function(){
  const form = document.getElementById('filtersForm');
  const tbody = document.getElementById('resultsTbody');
  const table = document.getElementById('resultsTable');
  const searchInput = document.getElementById('searchInput');
  const statusSelect = document.getElementById('statusSelect');
  const muniSelect = document.getElementById('muniSelect');

  if (!form || !tbody || !table) return;

  let debounceTimer = null;
  let lastQuery = null;
  let currentController = null;

  function buildQueryString(includeAjax = false){
    const fd = new FormData(form);
    const params = new URLSearchParams();

    for (const [k, v] of fd.entries()) {
      params.set(k, String(v ?? ''));
    }

    if (includeAjax) params.set('ajax', '1');
    return params.toString();
  }

  async function updateResults(){
    const active = document.activeElement;
    const wasSearchFocused = (active === searchInput);
    const caretStart = wasSearchFocused ? searchInput.selectionStart : null;
    const caretEnd = wasSearchFocused ? searchInput.selectionEnd : null;

    const qsAjax = buildQueryString(true);
    const qsUrl = buildQueryString(false);

    if (qsAjax === lastQuery) return;
    lastQuery = qsAjax;

    if (currentController) currentController.abort();
    currentController = new AbortController();

    table.classList.add('table-dim');

    try {
      const res = await fetch('complaints_list.php?' + qsAjax, {
        method: 'GET',
        headers: { 'X-Requested-With': 'XMLHttpRequest' },
        signal: currentController.signal
      });

      if (!res.ok) throw new Error('HTTP ' + res.status);

      const html = await res.text();
      tbody.innerHTML = html;

      history.replaceState(null, '', 'complaints_list.php' + (qsUrl ? ('?' + qsUrl) : ''));

      if (wasSearchFocused) {
        searchInput.focus({ preventScroll: true });
        if (caretStart !== null && caretEnd !== null) {
          searchInput.setSelectionRange(caretStart, caretEnd);
        }
      }
    } catch (err) {
      if (err && err.name === 'AbortError') return;
      console.error(err);
    } finally {
      table.classList.remove('table-dim');
    }
  }

  function updateDebounced(ms){
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(updateResults, ms);
  }

  if (searchInput){
    searchInput.addEventListener('input', () => updateDebounced(250));
    searchInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        updateResults();
      }
    });
  }

  if (statusSelect) statusSelect.addEventListener('change', updateResults);
  if (muniSelect) muniSelect.addEventListener('change', () => {
    if (muniSelect.disabled) return;
    updateResults();
  });

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    updateResults();
  });
})();
</script>

<?php include __DIR__ . "/partials/layout_bottom.php"; ?>