<?php
// Forward logout to unified portal logout
header("Location: /core/logout.php");
exit;