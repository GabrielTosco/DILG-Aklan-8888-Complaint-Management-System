<?php
// dilg8888/login.php
// ✅ DILG8888 login is deprecated. Use the unified Core login so the session cookie
// is shared across /core, /dilg8888, and /elista.
header('Location: /core/login.php');
exit;
