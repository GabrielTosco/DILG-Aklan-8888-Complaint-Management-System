<?php
function audit_log($pdo, $complaint_id, $user_id, $action, $details = null) {
    $stmt = $pdo->prepare("
        INSERT INTO audit_logs (complaint_id, user_id, action, details)
        VALUES (?, ?, ?, ?)
    ");
    $stmt->execute([$complaint_id, $user_id, $action, $details]);
}
    