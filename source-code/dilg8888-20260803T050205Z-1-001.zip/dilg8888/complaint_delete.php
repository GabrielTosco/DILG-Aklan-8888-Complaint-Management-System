<?php
require 'auth.php';
require 'config.php';

if (($_SESSION['role'] ?? '') !== 'encoder') {
    die("Access denied.");
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) die("Invalid complaint ID.");

// Load complaint
$stmt = $pdo->prepare("SELECT c.*, m.name AS municipality_name FROM complaints c LEFT JOIN municipalities m ON c.municipality_id = m.id WHERE c.id = ?");
$stmt->execute([$id]);
$c = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$c) die("Complaint not found.");

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_delete'])) {
    // delete files (if they exist on disk)
    if (!empty($c['complaint_pdf_path']) && file_exists(__DIR__ . "/" . $c['complaint_pdf_path'])) {
        @unlink(__DIR__ . "/" . $c['complaint_pdf_path']);
    }
    if (!empty($c['resolution_pdf_path']) && file_exists(__DIR__ . "/" . $c['resolution_pdf_path'])) {
        @unlink(__DIR__ . "/" . $c['resolution_pdf_path']);
    }

    // delete row
    $del = $pdo->prepare("DELETE FROM complaints WHERE id = ?");
    $del->execute([$id]);

    header("Location: complaints_list.php");
    exit;
}

$displayUser = $_SESSION['username'] ?? (($_SESSION['role'] ?? '') ? strtoupper((string)$_SESSION['role']) : 'User');
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Citizen Complaints Monitoring - Delete Complaint</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <style>
        :root {
            --blue: #0a4aa6;
            --blue2: #0b61d8;
            --bg: #f3f6fb;
            --card: #ffffff;
            --line: #e5e7eb;
            --danger: #b00020;
        }

        * {
            box-sizing: border-box;
            font-family: Arial, Helvetica, sans-serif;
        }

        body {
            margin: 0;
            background: var(--bg);
        }

        .app {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 260px;
            background: var(--blue);
            color: #fff;
            transition: width .2s ease;
            overflow: hidden;
        }

        .sidebar.collapsed {
            width: 72px;
        }

        /* ===== BRAND / LOGO (FINAL) ===== */
        .brand {
            height: 90px;
            background: rgba(0, 0, 0, .15);
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 10px 12px;
            overflow: hidden;
        }

        .brand-logo-full {
            width: 100%;
            max-width: 260px;
            max-height: 76px;
            height: auto;
            object-fit: contain;
            display: block;
        }

        .brand-logo-icon {
            width: 56px;
            height: 56px;
            object-fit: contain;
            display: none;
        }

        .sidebar.collapsed .brand-logo-full {
            display: none;
        }

        .sidebar.collapsed .brand-logo-icon {
            display: block;
        }

        .nav {
            padding: 10px 0;
        }

        .nav a {
            display: flex;
            align-items: center;
            gap: 10px;
            color: #fff;
            text-decoration: none;
            padding: 12px 16px;
            white-space: nowrap;
        }

        .nav a.active {
            background: rgba(0, 0, 0, .18);
            font-weight: 700;
        }

        .nav a:hover {
            background: rgba(0, 0, 0, .12);
        }

        .nav .icon {
            width: 34px;
            height: 34px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(255, 255, 255, .15);
            flex: 0 0 auto;
        }

        .sidebar.collapsed .nav span,
        .sidebar.collapsed .brand .title {
            display: none;
        }

        .main {
            flex: 1;
            display: flex;
            flex-direction: column;
        }

        .topbar {
            height: 60px;
            background: var(--blue2);
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 14px;
        }

        .topbar-left {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .burger {
            width: 44px;
            height: 44px;
            border-radius: 10px;
            border: none;
            background: rgba(0, 0, 0, .18);
            color: #fff;
            font-size: 22px;
            cursor: pointer;
        }

        .top-title {
            font-size: 26px;
            font-weight: 800;
            text-shadow: 0 2px 0 rgba(0, 0, 0, .3);
        }

        .topbar-right {
            display: flex;
            align-items: center;
            gap: 10px;
            font-weight: 700;
        }

        .avatar {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            background: rgba(0, 0, 0, .25);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .content {
            padding: 16px;
            max-width: 980px;
            margin: 0 auto;
            width: 100%;
        }

        h2 {
            margin: 8px 0 12px 0;
            text-align: center;
            font-size: 28px;
        }

        .card {
            background: var(--card);
            border: 1px solid var(--line);
            border-radius: 10px;
            overflow: hidden;
        }

        .card-header {
            background: #1b2fbf;
            color: #fff;
            padding: 10px 12px;
            font-weight: 900;
        }

        .pad {
            padding: 12px;
        }

        .grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
        }

        .box {
            border: 1px solid var(--line);
            border-radius: 10px;
            padding: 10px;
            background: #fff;
            min-width: 0;
        }

        .muted {
            color: #6b7280;
            font-size: 12px;
            margin-bottom: 6px;
            font-weight: 700;
        }

        .value {
            font-weight: 900;
            color: #111;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .danger {
            color: var(--danger);
            font-weight: 900;
            margin: 0 0 12px;
            text-align: center;
        }

        .actions {
            display: flex;
            gap: 10px;
            margin-top: 14px;
            justify-content: center;
            flex-wrap: wrap;
        }

        .btn {
            display: inline-block;
            padding: 10px 14px;
            border-radius: 10px;
            background: #fff;
            border: 1px solid var(--line);
            text-decoration: none;
            color: #111;
            font-weight: 900;
            cursor: pointer;
        }

        .btn:hover {
            background: #f2f6ff;
        }

        .btn-danger {
            background: var(--danger);
            border: 1px solid var(--danger);
            color: #fff;
        }

        .btn-danger:hover {
            opacity: .92;
        }
    </style>
</head>

<body>

    <div class="app">
        <!-- SIDEBAR -->
        <aside class="sidebar" id="sidebar">
            <div class="brand">
                <img src="assets/img/logo_full.png" class="brand-logo-full" alt="EP 8888 Logo">
                <img src="assets/img/logo_icon.png" class="brand-logo-icon" alt="EP 8888 Icon">
            </div>

            <nav class="nav">
                <a href="dashboard_analytics.php">
                    <div class="icon">🏠</div><span>Dashboard</span>
                </a>
                <a class="active" href="complaints_list.php">
                    <div class="icon">📄</div><span>Complaints List</span>
                </a>
                <a href="complaint_add.php">
                    <div class="icon">➕</div><span>Add Complaint</span>
                </a>
                <a href="users_list.php">
                    <div class="icon">👥</div><span>Users</span>
                </a>

                <a href="user_add.php">
                    <div class="icon">🧑‍💼</div><span>Add New User</span>
                </a>
                <a href="logout.php">
                    <div class="icon">🚪</div><span>Logout</span>
                </a>
            </nav>
        </aside>

        <!-- MAIN -->
        <main class="main">
            <div class="topbar">
                <div class="topbar-left">
                    <button class="burger" id="burger" title="Toggle sidebar">☰</button>
                    <div class="top-title">Citizen Complaints Monitoring</div>
                </div>
                <div class="topbar-right">
                    Admin
                </div>
            </div>

            <div class="content">
                <h2>Delete Complaint #<?php echo (int)$id; ?></h2>

                <div class="card">
                    <div class="card-header">Confirm Delete</div>
                    <div class="pad">
                        <p class="danger">Are you sure you want to delete this complaint?</p>

                        <div class="grid">
                            <div class="box">
                                <div class="muted">Tracking Number</div>
                                <div class="value"><?php echo htmlspecialchars($c['tracking_no'] ?? '—'); ?></div>
                            </div>
                            <div class="box">
                                <div class="muted">Municipality</div>
                                <div class="value"><?php echo htmlspecialchars($c['municipality_name'] ?? ($c['municipality'] ?? '—')); ?></div>
                            </div>
                            <div class="box" style="grid-column: 1 / -1;">
                                <div class="muted">Subject</div>
                                <div style="font-weight:800;color:#111;word-break:break-word;">
                                    <?php echo htmlspecialchars($c['subject'] ?? '—'); ?>
                                </div>
                            </div>
                        </div>

                        <div class="actions">
                            <a class="btn" href="complaints_list.php">Cancel</a>

                            <form method="POST" style="margin:0;">
                                <button class="btn btn-danger" type="submit" name="confirm_delete" value="1">Yes, Delete</button>
                            </form>
                        </div>
                    </div>
                </div>

            </div>
        </main>
    </div>

    <script>
        const sidebar = document.getElementById('sidebar');
        document.getElementById('burger').addEventListener('click', () => {
            sidebar.classList.toggle('collapsed');
        });
    </script>

</body>

</html>
