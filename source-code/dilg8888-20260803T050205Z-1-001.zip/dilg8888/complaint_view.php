<?php
require 'auth.php';
require 'config.php';
require_once __DIR__ . '/audit.php';

$role = $_SESSION['role'] ?? 'viewer';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
    die("Invalid complaint ID.");
}

// Fetch complaint (restrict responder to their municipality)
if ($role === 'responder' || $role === 'mlgoo') {
    $stmt = $pdo->prepare("
        SELECT c.*, m.name AS municipality_name
        FROM complaints c
        JOIN municipalities m ON m.id = c.municipality_id
        WHERE c.id = ? AND c.municipality_id = ?
    ");
    $stmt->execute([$id, $_SESSION['municipality_id']]);
} else {
    $stmt = $pdo->prepare("
        SELECT c.*, m.name AS municipality_name
        FROM complaints c
        JOIN municipalities m ON m.id = c.municipality_id
        WHERE c.id = ?
    ");
    $stmt->execute([$id]);
}

$c = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$c) {
    die("Complaint not found or access denied.");
}

$message = "";
$error = "";

// ✅ allow success message from redirect
if (!empty($_GET['msg'])) {
    $message = (string)$_GET['msg'];
}

// ✅ AUTO-MARK AS SEEN when responder opens complaint (notifications disappear)
if ($role === 'responder' && empty($c['received_at'])) {
    $upd = $pdo->prepare("UPDATE complaints SET received_at = NOW() WHERE id = ?");
    $upd->execute([$id]);

    // refresh local data
    $stmt->execute([$id, $_SESSION['municipality_id']]);
    $c = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Responder acknowledges "Received" (kept, but usually already set by auto-seen)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ack_received'])) {
    if ($role !== 'responder') die("Access denied.");

    if (empty($c['received_at'])) {
        $upd = $pdo->prepare("UPDATE complaints SET received_at = NOW() WHERE id = ?");
        $upd->execute([$id]);

        audit_log($pdo, $id, $_SESSION['user_id'], 'ACK_RECEIVED', 'Responder acknowledged received');
        $message = "Acknowledged (opened) by municipality.";
    } else {
        $message = "Already marked as received.";
    }
}

/* =========================
   ✅ COMMENT NOTIFICATIONS TABLE (safe)
   ========================= */
$pdo->exec("
    CREATE TABLE IF NOT EXISTS comment_notifications (
      id INT AUTO_INCREMENT PRIMARY KEY,
      complaint_id INT NOT NULL,
      comment_id INT NOT NULL,
      from_user_id INT NOT NULL,
      to_user_id INT NOT NULL,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      seen_at DATETIME NULL,
      UNIQUE KEY uniq_comment_to (comment_id, to_user_id),
      INDEX idx_to_seen_time (to_user_id, seen_at, created_at),
      INDEX idx_complaint (complaint_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");


/* =========================
   ✅ COMPLETION NOTIFICATIONS TABLE (safe)
   ========================= */
$pdo->exec("
    CREATE TABLE IF NOT EXISTS completion_notifications (
      id INT AUTO_INCREMENT PRIMARY KEY,
      complaint_id INT NOT NULL,
      from_user_id INT NOT NULL,
      to_user_id INT NOT NULL,
      completed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      seen_at DATETIME NULL,
      UNIQUE KEY uniq_complete_event (complaint_id, to_user_id, completed_at),
      INDEX idx_to_seen_time (to_user_id, seen_at, completed_at),
      INDEX idx_complaint (complaint_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

// Handle new comment (all roles allowed) + create notifications
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_comment'])) {
    $comment_text = trim($_POST['comment_text'] ?? '');

    if ($comment_text === '') {
        $error = "Comment cannot be empty.";
    } else {

        // 1) Insert comment
        $ins = $pdo->prepare("
            INSERT INTO complaint_comments (complaint_id, user_id, comment_text)
            VALUES (?, ?, ?)
        ");
        $ins->execute([$id, $_SESSION['user_id'], $comment_text]);
        $commentId = (int)$pdo->lastInsertId();

        // 2) Create notifications depending on who commented
        $fromUserId = (int)$_SESSION['user_id'];
        $fromRole   = $_SESSION['role'] ?? 'viewer';

        $complaintMunicipalityId = (int)($c['municipality_id'] ?? 0);
        $encodedByUserId = (int)($c['encoded_by_user_id'] ?? 0);

        $notifIns = $pdo->prepare("
            INSERT INTO comment_notifications (complaint_id, comment_id, from_user_id, to_user_id, created_at, seen_at)
            VALUES (?, ?, ?, ?, NOW(), NULL)
            ON DUPLICATE KEY UPDATE created_at = VALUES(created_at)
        ");

        if ($fromRole === 'encoder') {
            // ✅ Encoder -> notify LGU(responder) + MLGOO for that municipality
            $rcp = $pdo->prepare("
                SELECT id
                FROM users
                WHERE municipality_id = ?
                  AND role IN ('responder','mlgoo')
            ");
            $rcp->execute([$complaintMunicipalityId]);
            $toIds = $rcp->fetchAll(PDO::FETCH_COLUMN);

            foreach ($toIds as $toId) {
                $toId = (int)$toId;
                if ($toId > 0 && $toId !== $fromUserId) {
                    $notifIns->execute([$id, $commentId, $fromUserId, $toId]);
                }
            }
        } elseif ($fromRole === 'responder' || $fromRole === 'mlgoo') {
            // ✅ LGU/MLGOO -> notify encoder who encoded this complaint
            if ($encodedByUserId > 0 && $encodedByUserId !== $fromUserId) {
                $notifIns->execute([$id, $commentId, $fromUserId, $encodedByUserId]);
            }
        }

        audit_log($pdo, $id, $_SESSION['user_id'], 'ADD_COMMENT', 'Added a comment');
        $message = "Comment added.";
    }
}

// Encoder marks COMPLETE
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mark_complete'])) {
    if ($role !== 'encoder') die("Access denied.");

    if (empty($c['resolution_pdf_path'])) {
        $error = "Cannot mark COMPLETE: no resolution PDF uploaded yet.";
    } else {
        $upd = $pdo->prepare("UPDATE complaints SET status = 'COMPLETE' WHERE id = ?");
        $upd->execute([$id]);


        // ✅ Notify LGU / MLGOO that encoder completed the complaint
        $fromUserId = (int)$_SESSION['user_id'];
        $complaintMunicipalityId = (int)($c['municipality_id'] ?? 0);

        if ($complaintMunicipalityId > 0) {
            $rcp = $pdo->prepare("
                SELECT id
                FROM users
                WHERE municipality_id = ?
                  AND role IN ('responder','mlgoo')
            ");
            $rcp->execute([$complaintMunicipalityId]);
            $toIds = $rcp->fetchAll(PDO::FETCH_COLUMN);

            $ins = $pdo->prepare("
                INSERT INTO completion_notifications (complaint_id, from_user_id, to_user_id, completed_at)
                VALUES (?, ?, ?, NOW())
            ");

            foreach ($toIds as $toId) {
                $toId = (int)$toId;
                if ($toId > 0 && $toId !== $fromUserId) {
                    $ins->execute([$id, $fromUserId, $toId]);
                }
            }
        }

        audit_log($pdo, $id, $_SESSION['user_id'], 'MARK_COMPLETE', 'Marked complaint COMPLETE');
        $message = "Complaint marked as COMPLETE.";
    }
}

// Refresh complaint after actions
if ($role === 'responder' || $role === 'mlgoo') {
    $stmt->execute([$id, $_SESSION['municipality_id']]);
} else {
    $stmt->execute([$id]);
}
$c = $stmt->fetch(PDO::FETCH_ASSOC);

// Load comments
$comStmt = $pdo->prepare("
    SELECT cc.*, u.username, u.role
    FROM complaint_comments cc
    JOIN users u ON u.id = cc.user_id
    WHERE cc.complaint_id = ?
    ORDER BY cc.created_at ASC
");
$comStmt->execute([$id]);
$comments = $comStmt->fetchAll(PDO::FETCH_ASSOC);

/* ✅ NEW: Load STACKED revision requests (history) */
$revStmt = $pdo->prepare("
    SELECT rr.*, u.username, u.role
    FROM complaint_revision_requests rr
    JOIN users u ON u.id = rr.requested_by
    WHERE rr.complaint_id = ?
    ORDER BY rr.requested_at DESC
");
$revStmt->execute([$id]);
$revisionRequests = $revStmt->fetchAll(PDO::FETCH_ASSOC);

// Helpers
function fmt_dt_no_seconds($val)
{
    if (empty($val)) return '—';
    return date('Y-m-d h:i A', strtotime($val));
}

function calculate_elapsed_time($date_sent, $resolved_at)
{
    if (empty($date_sent) || empty($resolved_at)) return '—';

    try {
        $start = new DateTime($date_sent);
        $end   = new DateTime($resolved_at);
    } catch (Exception $e) {
        return '—';
    }

    $interval = $start->diff($end);
    $days = (int)$interval->days;

    if ($days <= 0) return 'Same day';
    if ($days === 1) return '1 day';
    return $days . ' days';
}

function na($val)
{
    $v = trim((string)$val);
    return ($v === '') ? 'N/A' : htmlspecialchars($v);
}

/* ✅ Page settings for global layout */
$pageTitle  = "Citizen Complaints Monitoring - Complaint View";
$activePage = "complaints";

/* ✅ Move page-specific CSS into extraHead */
$extraHead = <<<HTML
<style>
  h2 {
    color: #222;
    font-size: 28px;
    margin: 0 0 20px;
  }

  .btn {
    display: inline-block;
    padding: 10px 18px;
    background: var(--blue);
    color: #fff;
    text-decoration: none;
    border-radius: 6px;
    font-size: 14px;
    transition: background .2s;
    border: none;
    cursor: pointer;
  }

  .btn:hover { background: var(--blue2); }
  .btn-primary { background: var(--blue); }
  .btn-primary:hover { background: var(--blue2); }

  .btn-danger { background: #dc2626; }
  .btn-danger:hover { background: #b91c1c; }

  .alert {
    padding: 12px 16px;
    border-radius: 6px;
    margin-bottom: 16px;
    font-size: 14px;
    border: 1px solid var(--line);
    background: #f9fafb;
  }

  .alert.ok {
    background: #d1fae5;
    color: #065f46;
    border: 1px solid #6ee7b7;
  }

  .alert.err {
    background: #fee2e2;
    color: #991b1b;
    border: 1px solid #fca5a5;
  }

  .grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
    margin-bottom: 20px;
  }

  @media (max-width: 768px) {
    .grid { grid-template-columns: 1fr; }
  }

  .card {
    background: var(--card);
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, .08);
  }

  .card-header {
    padding: 16px 20px;
    border-bottom: 1px solid var(--line);
    font-weight: bold;
    font-size: 16px;
    display: flex;
    align-items: center;
    justify-content: space-between;
  }

  .pad { padding: 20px; }

  .info-row {
    display: flex;
    margin-bottom: 12px;
    padding-bottom: 12px;
    border-bottom: 1px solid var(--line);
  }

  .info-row:last-child {
    border-bottom: none;
    margin-bottom: 0;
    padding-bottom: 0;
  }

  .info-row .k {
    font-weight: 600;
    width: 160px;
    flex-shrink: 0;
    color: #374151;
  }

  .info-row .v { flex: 1; color: #111827; word-break: break-word; }

  .subject-collapsed {
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }

  .see-all-btn {
    background: none;
    border: none;
    color: var(--blue);
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    padding: 4px 0 0;
    display: inline-block;
    text-decoration: underline;
  }
  .see-all-btn:hover { color: var(--blue2); }

  .file-link {
    color: var(--blue);
    text-decoration: none;
    font-weight: 600;
  }

  .file-link:hover { text-decoration: underline; }

  .status-pill {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 600;
  }

  .st-complete { background: #d1fae5; color: #065f46; }
  .st-pending  { background: #fef3c7; color: #92400e; }
  .st-revising { background: #fee2e2; color: #991b1b; }
  .st-received { background: #dbeafe; color: #1e40af; }

  .comment {
    background: #f9fafb;
    padding: 12px 16px;
    border-radius: 6px;
    margin-bottom: 12px;
    border: 1px solid var(--line);
  }

  .comment .meta {
    font-size: 13px;
    color: #6b7280;
    margin-bottom: 6px;
  }

  .comment .text { color: #111827; font-size: 14px; }

  textarea {
    width: 100%;
    padding: 10px 12px;
    border: 1px solid #ccc;
    border-radius: 6px;
    font-size: 14px;
    font-family: Arial, Helvetica, sans-serif;
    resize: vertical;
  }

  textarea:focus {
    outline: none;
    border-color: var(--blue);
  }

  .rev-box{
    background:#fff7ed;
    border:1px solid #fdba74;
    color:#9a3412;
    padding:12px 14px;
    border-radius:8px;
    font-size:14px;
    line-height:1.4;
    margin-bottom:10px;
  }
  .rev-box:last-child{ margin-bottom:0; }
</style>
HTML;

/* ✅ include global header/sidebar */
include __DIR__ . "/partials/layout_top.php";
?>

<h2>Complaint Details</h2>

<div style="text-align:center;margin-bottom:12px;">
    <a class="btn" href="complaints_list.php">← Back to Complaints List</a>
</div>

<?php if ($message): ?>
    <div class="alert ok"><?php echo htmlspecialchars($message); ?></div>
<?php endif; ?>
<?php if ($error): ?>
    <div class="alert err"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<!-- Complaint Details (full width) -->
<div class="card" style="margin-bottom:20px;">
    <div class="card-header">
        <span>Complaint Details</span>
        <?php
        $st = strtoupper($c['status']);
        // ✅ UI label only (keep DB value as REVISING)
        $stDisplay = ($st === 'REVISING') ? 'FOR CORRECTION' : $st;
        $stClass = $st === 'COMPLETE' ? 'st-complete'
            : ($st === 'PENDING' ? 'st-pending'
                : ($st === 'REVISING' ? 'st-revising'
                    : 'st-received'));
        ?>
        <span class="status-pill <?php echo $stClass; ?>"><?php echo htmlspecialchars($stDisplay); ?></span>
    </div>

    <div class="pad">
        <div class="info-row">
            <div class="k">Ticket Reference Number</div>
            <div class="v"><?php echo na($c['tracking_no'] ?? ''); ?></div>
        </div>

        <div class="info-row">
            <div class="k">Date</div>
            <div class="v"><?php echo htmlspecialchars(fmt_dt_no_seconds($c['date_sent'] ?? null)); ?></div>
        </div>

        <div class="info-row">
            <div class="k">Nature of Call</div>
            <div class="v"><?php echo na($c['nature_of_call'] ?? ''); ?></div>
        </div>

        <div class="info-row">
            <div class="k">Subject</div>
            <div class="v">
                <?php
                $subjectText = na($c['subject'] ?? '');
                $isLong = mb_strlen(strip_tags($subjectText)) > 200;
                ?>
                <?php if ($isLong): ?>
                    <div id="subject-text" class="subject-collapsed"><?php echo $subjectText; ?></div>
                    <button class="see-all-btn" id="subject-toggle" onclick="toggleSubject()">... See all</button>
                    <script>
                        function toggleSubject() {
                            var el = document.getElementById('subject-text');
                            var btn = document.getElementById('subject-toggle');
                            if (el.classList.contains('subject-collapsed')) {
                                el.classList.remove('subject-collapsed');
                                btn.textContent = 'Show less';
                            } else {
                                el.classList.add('subject-collapsed');
                                btn.textContent = '... See all';
                            }
                        }
                    </script>
                <?php else: ?>
                    <?php echo $subjectText; ?>
                <?php endif; ?>
            </div>
        </div>

        <div class="info-row">
            <div class="k">Focal Person</div>
            <div class="v"><?php echo na($c['complainant'] ?? ''); ?></div>
        </div>

        <div class="info-row">
            <div class="k">Name of Client</div>
            <div class="v"><?php echo na($c['client_name'] ?? ''); ?></div>
        </div>

        <div class="info-row">
            <div class="k">Address</div>
            <div class="v"><?php echo na($c['address'] ?? ''); ?></div>
        </div>

        <div class="info-row">
            <div class="k">Contact Details</div>
            <div class="v"><?php echo na($c['contact_details'] ?? ''); ?></div>
        </div>

        <div class="info-row">
            <div class="k">Municipality</div>
            <div class="v"><?php echo htmlspecialchars($c['municipality_name']); ?></div>
        </div>

        <div class="info-row">
            <div class="k">Date Resolved</div>
            <div class="v"><?php echo !empty($c['resolved_at']) ? date('Y-m-d h:i A', strtotime($c['resolved_at'])) : '—'; ?></div>
        </div>

        <!-- ✅ ADDED: ELAPSED TIME (same logic as list) -->
        <div class="info-row">
            <div class="k">Elapsed Time</div>
            <div class="v"><?php echo htmlspecialchars(calculate_elapsed_time($c['date_sent'] ?? null, $c['resolved_at'] ?? null)); ?></div>
        </div>

        <div style="height:12px;"></div>

        <div class="card" style="border-radius:10px;">
            <div class="card-header">Files</div>
            <div class="pad">
                <p style="margin:0 0 10px 0;">
                    <b>Complaint PDF:</b>
                    <a class="file-link" href="<?php echo htmlspecialchars($c['complaint_pdf_path']); ?>" target="_blank">Open</a>
                </p>

                <p style="margin:0;">
                    <b>Resolution PDF:</b>
                    <?php if (!empty($c['resolution_pdf_path'])): ?>
                        <a class="file-link" href="<?php echo htmlspecialchars($c['resolution_pdf_path']); ?>" target="_blank">Open</a>
                    <?php else: ?>
                        —
                    <?php endif; ?>
                </p>
            </div>
        </div>
    </div>
</div>

<!-- Actions (full width, below details) -->
<div class="card" style="margin-bottom:20px;">
    <div class="card-header">Actions</div>
    <div class="pad">

        <!-- ✅ STACKED REVISION REMARKS (VISIBLE TO ALL USERS) -->
        <?php if (!empty($revisionRequests)): ?>
            <div class="card" style="border-radius:10px;margin-bottom:12px;">
                <div class="card-header">Revision Remarks (History)</div>
                <div class="pad">
                    <?php foreach ($revisionRequests as $rr): ?>
                        <div class="rev-box">
                            <?php echo nl2br(htmlspecialchars($rr['remarks'])); ?>
                            <div style="margin-top:8px;font-size:12px;opacity:.85;">
                                Requested by: <b><?php echo htmlspecialchars($rr['username']); ?></b>
                                (<?php echo htmlspecialchars($rr['role']); ?>)
                                — <?php echo htmlspecialchars(fmt_dt_no_seconds($rr['requested_at'] ?? null)); ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($role === 'responder'): ?>
            <div class="card" style="border-radius:10px;margin-bottom:12px;">
                <div class="card-header">Responder Actions</div>
                <div class="pad">

                    <?php if (empty($c['received_at'])): ?>
                        <form method="post" onsubmit="return confirm('Confirm you received this complaint?');">
                            <button class="btn btn-primary" type="submit" name="ack_received">Received</button>
                        </form>
                    <?php endif; ?>

                    <div style="height:10px;"></div>

                    <?php if ($c['status'] === 'PENDING' || $c['status'] === 'REFERRED' || $c['status'] === 'REVISING'): ?>
                        <a class="btn btn-primary" href="resolution_upload.php?id=<?php echo (int)$c['id']; ?>">
                            Upload / Replace Resolution PDF
                        </a>
                    <?php elseif ($c['status'] === 'COMPLETE'): ?>
                        <div class="alert">This complaint is COMPLETE. If encoder requests revision, you can upload again.</div>
                    <?php endif; ?>

                </div>
            </div>
        <?php endif; ?>

        <?php if ($role === 'encoder'): ?>
            <div class="card" style="border-radius:10px;">
                <div class="card-header">Encoder Actions</div>
                <div class="pad">
                    <?php if ($c['status'] === 'REVISING'): ?>
                        <div class="alert">This complaint is <b>FOR CORRECTION</b>. Waiting for the LGU to re-upload the resolution before you can take action.</div>
                    <?php else: ?>
                        <?php if ($c['status'] === 'PENDING'): ?>
                            <form method="post" onsubmit="return confirm('Mark this complaint as COMPLETE?');" style="display:inline-block;">
                                <button class="btn btn-primary" type="submit" name="mark_complete">Mark as COMPLETE</button>
                            </form>
                        <?php endif; ?>

                        <a class="btn btn-danger" style="margin-left:10px;"
                            href="complaint_revision_request.php?id=<?php echo (int)$c['id']; ?>"
                            onclick="return confirm('Are you sure you want to request a revision?');">
                            Request Revision
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($role === 'viewer'): ?>
            <div class="alert">Viewer account: you can view and download files and post comments.</div>
        <?php endif; ?>

    </div>
</div>

<!-- COMMENTS -->
<div class="card">
    <div class="card-header">Comments</div>
    <div class="pad">

        <?php if (count($comments) === 0): ?>
            <div class="alert">No comments yet.</div>
        <?php else: ?>
            <?php foreach ($comments as $cm): ?>
                <div class="comment">
                    <div class="meta">
                        <b><?php echo htmlspecialchars($cm['username']); ?></b>
                        (<?php echo htmlspecialchars($cm['role']); ?>)
                        — <?php echo htmlspecialchars(fmt_dt_no_seconds($cm['created_at'] ?? null)); ?>
                    </div>
                    <div class="text"><?php echo htmlspecialchars($cm['comment_text']); ?></div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <div style="height:10px;"></div>

        <form method="post">
            <label style="font-weight:900;display:block;margin-bottom:8px;">Add a comment</label>
            <textarea name="comment_text" rows="4" required></textarea>
            <div style="height:10px;"></div>
            <button class="btn btn-primary" type="submit" name="add_comment">Post Comment</button>
        </form>

    </div>
</div>

<?php
include __DIR__ . "/partials/layout_bottom.php";
?>