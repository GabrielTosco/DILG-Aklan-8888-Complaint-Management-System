<?php
require 'auth.php';
require 'config.php';
require_once __DIR__ . '/audit.php';

$role = $_SESSION['role'] ?? 'viewer';
if ($role !== 'encoder') die("Access denied.");

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) die("Invalid complaint ID.");

// Load complaint
$stmt = $pdo->prepare("SELECT * FROM complaints WHERE id = ?");
$stmt->execute([$id]);
$c = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$c) die("Complaint not found.");

// Load municipalities
$muniStmt = $pdo->query("SELECT id, name FROM municipalities ORDER BY name ASC");
$municipalities = $muniStmt->fetchAll(PDO::FETCH_ASSOC);

$error = "";
$success = "";

// Helpers
function fmt_dt_no_seconds($val)
{
    if (empty($val)) return '—';
    return date('Y-m-d h:i A', strtotime($val));
}
function to_datetime_local($val)
{
    if (empty($val)) return '';
    return date('Y-m-d\TH:i', strtotime($val));
}
function to_mysql_datetime_from_local($val)
{
    if (empty($val)) return null;
    $ts = strtotime($val);
    if (!$ts) return null;
    return date('Y-m-d H:i:s', $ts);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $tracking_no     = trim($_POST['tracking_no'] ?? '');
    $subject         = trim($_POST['subject'] ?? '');
    $nature_of_call  = trim($_POST['nature_of_call'] ?? '');
    $focal_person    = trim($_POST['focal_person'] ?? '');
    $client_name     = trim($_POST['client_name'] ?? '');
    $address         = trim($_POST['address'] ?? '');
    $contact_details = trim($_POST['contact_details'] ?? '');

    $date_sent_local = trim($_POST['date_sent'] ?? '');
    $date_sent_new   = to_mysql_datetime_from_local($date_sent_local); // optional
    $municipality_id = (int)($_POST['municipality_id'] ?? 0);

    // ✅ Keep municipality strict (DB requires it)
    if ($municipality_id <= 0) {
        $error = "Please select a municipality.";
    } else {

        // subject is NOT strict — but DB requires NOT NULL
        if ($subject === '') $subject = 'N/A';

        // date_sent not strict — if blank, keep existing
        $date_sent = $date_sent_new ? $date_sent_new : ($c['date_sent'] ?? date('Y-m-d H:i:s'));

        $complaint_pdf_path = $c['complaint_pdf_path'];
        $resolution_pdf_path = $c['resolution_pdf_path'];

        // Replace complaint PDF (optional)
        if (isset($_FILES['complaint_pdf']) && $_FILES['complaint_pdf']['error'] === UPLOAD_ERR_OK) {
            $ext = strtolower(pathinfo($_FILES['complaint_pdf']['name'], PATHINFO_EXTENSION));
            if ($ext !== 'pdf') {
                $error = "Complaint file must be a PDF.";
            } else {
                $folder = __DIR__ . "/uploads/complaints/";
                if (!is_dir($folder)) mkdir($folder, 0777, true);

                $newName = "complaint_" . $id . "_" . time() . ".pdf";
                $dest = $folder . $newName;

                if (move_uploaded_file($_FILES['complaint_pdf']['tmp_name'], $dest)) {
                    if (!empty($complaint_pdf_path) && file_exists(__DIR__ . "/" . $complaint_pdf_path)) {
                        @unlink(__DIR__ . "/" . $complaint_pdf_path);
                    }
                    $complaint_pdf_path = "uploads/complaints/" . $newName;
                } else {
                    $error = "Failed to upload new complaint PDF.";
                }
            }
        }

        // Replace resolution PDF (optional)
        if ($error === "" && isset($_FILES['resolution_pdf']) && $_FILES['resolution_pdf']['error'] === UPLOAD_ERR_OK) {
            $ext2 = strtolower(pathinfo($_FILES['resolution_pdf']['name'], PATHINFO_EXTENSION));
            if ($ext2 !== 'pdf') {
                $error = "Resolution file must be a PDF.";
            } else {
                $folder2 = __DIR__ . "/uploads/resolutions/";
                if (!is_dir($folder2)) mkdir($folder2, 0777, true);

                $newName2 = "resolution_" . $id . "_" . time() . ".pdf";
                $dest2 = $folder2 . $newName2;

                if (move_uploaded_file($_FILES['resolution_pdf']['tmp_name'], $dest2)) {
                    if (!empty($resolution_pdf_path) && file_exists(__DIR__ . "/" . $resolution_pdf_path)) {
                        @unlink(__DIR__ . "/" . $resolution_pdf_path);
                    }
                    $resolution_pdf_path = "uploads/resolutions/" . $newName2;
                } else {
                    $error = "Failed to upload new resolution PDF.";
                }
            }
        }

        if ($error === "") {
            $upd = $pdo->prepare("
                UPDATE complaints
                SET tracking_no = ?,
                    subject = ?,
                    nature_of_call = ?,
                    complainant = ?,
                    client_name = ?,
                    address = ?,
                    contact_details = ?,
                    date_sent = ?,
                    municipality_id = ?,
                    complaint_pdf_path = ?,
                    resolution_pdf_path = ?
                WHERE id = ?
            ");
            $upd->execute([
                ($tracking_no !== '' ? $tracking_no : null),
                $subject,
                ($nature_of_call !== '' ? $nature_of_call : null),
                ($focal_person !== '' ? $focal_person : null),
                ($client_name !== '' ? $client_name : null),
                ($address !== '' ? $address : null),
                ($contact_details !== '' ? $contact_details : null),
                $date_sent,
                $municipality_id,
                $complaint_pdf_path,
                $resolution_pdf_path,
                $id
            ]);

            audit_log($pdo, $id, $_SESSION['user_id'], 'EDIT_COMPLAINT', 'Edited complaint details and/or files');

            $success = "Complaint updated successfully.";

            // refresh complaint
            $stmt->execute([$id]);
            $c = $stmt->fetch(PDO::FETCH_ASSOC);
        }
    }
}

/* ✅ Page settings for global layout */
$pageTitle  = "Citizen Complaints Monitoring - Edit Complaint";
$activePage = "complaints";

$extraHead = <<<HTML
<style>
  h2 { color:#222; font-size:28px; margin:0 0 20px; }
  .btn { display:inline-block; padding:10px 18px; background:var(--blue); color:#fff; text-decoration:none; border-radius:6px; font-size:14px; transition:background .2s; border:none; cursor:pointer; }
  .btn:hover { background:var(--blue2); }
  .card { background: var(--card); border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,.08); }
  .card-header { padding: 16px 20px; border-bottom: 1px solid var(--line); font-weight: bold; font-size: 16px; }
  .pad { padding: 20px; }
  .alert { padding: 12px 16px; border-radius: 6px; margin-bottom: 16px; font-size: 14px; border: 1px solid var(--line); background: #fff; font-weight: 800; }
  .alert.ok { border-color:#b7ebc6; background:#e8fff1; }
  .alert.err { border-color:#f2b8b8; background:#ffecec; }
  label { font-weight: 900; }
  input[type="text"], input[type="datetime-local"], select {
    width:100%; padding:10px 10px; border:1px solid var(--line); border-radius:10px; font-size:14px; background:#fff;
  }
  input[type="file"] { width:100%; padding:10px 10px; border:1px solid var(--line); border-radius:10px; background:#fff; }
  .row { margin-bottom: 12px; }
  .top-actions { display:flex; gap:10px; justify-content:center; flex-wrap:wrap; margin-bottom:12px; }
  .file-link { font-weight: 900; text-decoration:none; color: var(--blue); }
  .file-link:hover { text-decoration: underline; }
  .mini-note { font-size:12px; color:#666; margin-top:6px; }
</style>
HTML;

include __DIR__ . "/partials/layout_top.php";
?>

<h2>Edit Complaint #<?php echo (int)$id; ?></h2>

<div class="top-actions">
  <a class="btn" href="complaints_list.php">← Back to Complaints List</a>
  <a class="btn" href="complaint_view.php?id=<?php echo (int)$id; ?>">Open Complaint View</a>
</div>

<?php if ($error): ?>
  <div class="alert err"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>
<?php if ($success): ?>
  <div class="alert ok"><?php echo htmlspecialchars($success); ?></div>
<?php endif; ?>

<div class="card">
  <div class="card-header">Edit Form</div>
  <div class="pad">
    <form method="post" enctype="multipart/form-data">

      <div class="row">
        <label>Ticket Reference Number</label>
        <input type="text" name="tracking_no" value="<?php echo htmlspecialchars($c['tracking_no'] ?? ''); ?>">
      </div>

      <div class="row">
        <label>Date</label>
        <input type="datetime-local" name="date_sent" value="<?php echo htmlspecialchars(to_datetime_local($c['date_sent'] ?? '')); ?>">
        <div class="mini-note">Current: <?php echo htmlspecialchars(fmt_dt_no_seconds($c['date_sent'] ?? null)); ?> (leave blank to keep current)</div>
      </div>

      <div class="row">
        <label>Nature of Call</label>
        <input type="text" name="nature_of_call" value="<?php echo htmlspecialchars($c['nature_of_call'] ?? ''); ?>">
      </div>

      <div class="row">
        <label>Subject</label>
        <input type="text" name="subject" value="<?php echo htmlspecialchars($c['subject'] ?? ''); ?>">
      </div>

      <div class="row">
        <label>Focal Person</label>
        <input type="text" name="focal_person" value="<?php echo htmlspecialchars($c['complainant'] ?? ''); ?>">
      </div>

      <div class="row">
        <label>Name of Client (optional)</label>
        <input type="text" name="client_name" value="<?php echo htmlspecialchars($c['client_name'] ?? ''); ?>">
      </div>

      <div class="row">
        <label>Address (optional)</label>
        <input type="text" name="address" value="<?php echo htmlspecialchars($c['address'] ?? ''); ?>">
      </div>

      <div class="row">
        <label>Contact Details (optional)</label>
        <input type="text" name="contact_details" value="<?php echo htmlspecialchars($c['contact_details'] ?? ''); ?>">
      </div>

      <div class="row">
        <label>Municipality *</label>
        <select name="municipality_id" required>
          <?php foreach ($municipalities as $m): ?>
            <option value="<?php echo (int)$m['id']; ?>" <?php if ((int)$c['municipality_id'] === (int)$m['id']) echo 'selected'; ?>>
              <?php echo htmlspecialchars($m['name']); ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="row">
        <div class="card" style="border-radius:10px;">
          <div class="card-header">Complaint PDF</div>
          <div class="pad">
            <p style="margin:0 0 10px 0;">
              <b>Current:</b>
              <a class="file-link" href="<?php echo htmlspecialchars($c['complaint_pdf_path']); ?>" target="_blank">Download</a>
            </p>

            <label>Replace Complaint PDF (optional)</label>
            <input type="file" name="complaint_pdf" accept="application/pdf">
          </div>
        </div>
      </div>

      <div class="row">
        <div class="card" style="border-radius:10px;">
          <div class="card-header">Resolution PDF</div>
          <div class="pad">
            <p style="margin:0 0 10px 0;">
              <b>Current:</b>
              <?php if (!empty($c['resolution_pdf_path'])): ?>
                <a class="file-link" href="<?php echo htmlspecialchars($c['resolution_pdf_path']); ?>" target="_blank">Download</a>
              <?php else: ?>
                —
              <?php endif; ?>
            </p>

            <label>Replace Resolution PDF (optional)</label>
            <input type="file" name="resolution_pdf" accept="application/pdf">
          </div>
        </div>
      </div>

      <button class="btn" type="submit">Save Changes</button>
    </form>

    <div style="height:12px;"></div>

    <div class="alert">
      <b>Date Received (Acknowledged by Municipality):</b>
      <?php echo htmlspecialchars(fmt_dt_no_seconds($c['received_at'] ?? null)); ?>
    </div>

  </div>
</div>

<?php include __DIR__ . "/partials/layout_bottom.php"; ?>